# CareTrack – Healthcare Management System

A complete full-stack healthcare management web application with role-based access for Admin, Doctor, and Patient.

## Features

- **Authentication**: JWT-based login/register with bcrypt password hashing
- **Role-based dashboards**: Admin, Doctor, and Patient views
- **Patient management**: CRUD operations, search, medical history
- **Doctor management**: Specializations, fees, availability
- **Appointment system**: Booking, status workflow (pending → approved → completed), double-booking prevention
- **Medical records**: Diagnosis, prescriptions, treatment notes, vital signs
- **Responsive UI**: Modern healthcare-themed interface with Tailwind CSS

## Tech Stack

| Layer    | Technologies                                      |
|----------|---------------------------------------------------|
| Frontend | React 18, Vite, Tailwind CSS, React Router, Axios |
| Backend  | Node.js, Express.js, MongoDB, Mongoose            |
| Auth     | JWT, bcryptjs                                     |

## Prerequisites

- Node.js 18+
- MongoDB (local or Atlas)
- npm or yarn

## Installation

### 1. Clone / Extract the project

```bash
cd caretrack
```

### 2. Backend setup

```bash
cd server
npm install
cp .env.example .env
# Edit .env if needed (MongoDB URI, JWT secret)
```

Start MongoDB locally, then seed the database:

```bash
npm run seed
```

Start the server:

```bash
npm run dev
# or: npm start
```

Server runs at **http://localhost:5000**

### 3. Frontend setup

```bash
cd client
npm install
cp .env.example .env
# VITE_API_URL defaults to http://localhost:5000/api
```

Start the development server:

```bash
npm run dev
```

Frontend runs at **http://localhost:3000**

## Default Credentials

| Role    | Email                       | Password    |
|---------|-----------------------------|-------------|
| Admin   | admin@caretrack.com         | admin123    |
| Doctor  | doctor@caretrack.com        | doctor123   |
| Doctor  | dr.smith@caretrack.com      | doctor123   |
| Doctor  | dr.patel@caretrack.com      | doctor123   |
| Doctor  | dr.chen@caretrack.com       | doctor123   |
| Patient | patient@caretrack.com       | patient123  |

After `npm run seed` you also get **8 doctors**, **12 patients**, sample **appointments**, and **medical records**.

All other seeded doctors use password `doctor123`. Other seeded patients use `patient123`.

> Admin accounts cannot be created via public registration. Use the seed script or **Registration Station** (admin sidebar) to add doctors and patients.



## Role-Based Access Control (RBAC)

Three roles with server-enforced permissions:

| Capability | Admin | Doctor | Patient |
|------------|:-----:|:------:|:-------:|
| Admin dashboard & stats | Yes | — | — |
| Registration Station | Yes | — | — |
| Manage patients (CRUD) | Yes | View list | Own profile only |
| Manage doctors (CRUD) | Yes | Own profile | Browse only |
| Book appointment | Yes | — | Yes |
| Approve / complete appointment | Yes | Yes | Cancel own |
| Create medical records | Yes | Yes | — |
| View medical records | All | Own patients | Own only |

**Server:** `middleware/auth.js` → `protect` + `authorize(roles)` + `requirePermission(keys)`  
**Matrix:** `config/permissions.js`  
**Client:** `utils/permissions.js`, `RoleGate`, route `roles={[...]}` in `App.jsx`

Login and `GET /api/auth/me` return a `permissions` array for the UI.

## API Endpoints

### Auth
| Method | Endpoint            | Access  | Description          |
|--------|---------------------|---------|----------------------|
| POST   | /api/auth/register  | Public  | Register patient     |
| POST   | /api/auth/login     | Public  | Login                |
| GET    | /api/auth/me        | Private | Current user         |
| PUT    | /api/auth/profile   | Private | Update profile       |

### Patients
| Method | Endpoint                    | Access        | Description        |
|--------|-----------------------------|---------------|--------------------|
| GET    | /api/patients               | Admin, Doctor | List patients      |
| POST   | /api/patients               | Admin         | Create patient     |
| GET    | /api/patients/:id           | Private       | Get patient        |
| PUT    | /api/patients/:id           | Private       | Update patient     |
| DELETE | /api/patients/:id           | Admin         | Delete patient     |
| GET    | /api/patients/me/profile    | Patient       | Own profile        |

### Doctors
| Method | Endpoint                  | Access        | Description       |
|--------|---------------------------|---------------|-------------------|
| GET    | /api/doctors              | Public        | List doctors      |
| POST   | /api/doctors              | Admin         | Create doctor     |
| GET    | /api/doctors/:id          | Public        | Get doctor        |
| PUT    | /api/doctors/:id          | Admin, Doctor | Update doctor     |
| DELETE | /api/doctors/:id          | Admin         | Delete doctor     |

### Appointments
| Method | Endpoint                          | Access  | Description          |
|--------|-----------------------------------|---------|----------------------|
| GET    | /api/appointments                 | Private | List (role-filtered) |
| POST   | /api/appointments                 | Private | Book appointment     |
| GET    | /api/appointments/:id             | Private | Get appointment      |
| PUT    | /api/appointments/:id             | Private | Update status/details|
| DELETE | /api/appointments/:id             | Admin   | Delete               |
| GET    | /api/appointments/stats/dashboard | Admin   | Dashboard stats      |

### Medical Records
| Method | Endpoint                  | Access        | Description        |
|--------|---------------------------|---------------|--------------------|
| GET    | /api/medical-records      | Private       | List (role-filtered)|
| POST   | /api/medical-records      | Doctor, Admin | Create record      |
| GET    | /api/medical-records/:id  | Private       | Get record         |
| PUT    | /api/medical-records/:id  | Doctor, Admin | Update record      |
| DELETE | /api/medical-records/:id  | Admin         | Delete record      |

## Project Structure

```
caretrack/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Route pages
│   │   ├── layouts/        # Layout wrappers
│   │   ├── context/        # Auth context
│   │   ├── services/       # API client
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
├── server/                 # Express backend
│   ├── config/             # DB connection
│   ├── controllers/        # Route handlers
│   ├── middleware/         # Auth & validation
│   ├── models/             # Mongoose models
│   ├── routes/             # API routes
│   ├── scripts/            # Seed script
│   ├── server.js
│   └── package.json
└── README.md
```

## Environment Variables

### Server (`.env`)
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/caretrack
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRE=7d
NODE_ENV=development
```

### Client (`.env`)
```
VITE_API_URL=http://localhost:5000/api
```

## Appointment Workflow

1. Patient books an appointment → status: **pending**
2. Doctor/Admin approves or rejects → **approved** / **rejected**
3. Doctor completes visit and adds medical record → **completed**
4. Patient can cancel pending/approved appointments → **cancelled**

Double-booking for the same doctor + date + time is prevented.

## License

MIT
```

## New AI features

- **AI Chat Assistant** is available from the sidebar for all signed-in roles. To enable live AI replies, add `OPENAI_API_KEY=your_key` and optionally `OPENAI_MODEL=gpt-4o-mini` to `server/.env`, then restart the backend. The key stays on the server; do not put it in the React client. Without a key, the chat shows a setup message.
- **AI Chart Box** is available to admin and doctor roles. It loads appointment and patient records permitted by the signed-in user's role and displays appointment-status counts. These are descriptive charts, not AI-generated medical predictions.

After updating `server/.env`, restart the backend. Start the frontend as usual with `npm run dev` from `client`.
