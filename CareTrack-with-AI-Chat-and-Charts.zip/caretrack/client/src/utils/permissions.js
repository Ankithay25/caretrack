/**
 * Frontend RBAC — mirror of server role permissions.
 * Use with useAuth().user.role or permissions array from API.
 */

export const ROLES = {
  ADMIN: 'admin',
  DOCTOR: 'doctor',
  PATIENT: 'patient',
};

export const PERMISSIONS = {
  VIEW_ADMIN_DASHBOARD: 'view_admin_dashboard',
  VIEW_DOCTOR_DASHBOARD: 'view_doctor_dashboard',
  VIEW_PATIENT_DASHBOARD: 'view_patient_dashboard',
  LIST_PATIENTS: 'list_patients',
  CREATE_PATIENT: 'create_patient',
  UPDATE_PATIENT: 'update_patient',
  DELETE_PATIENT: 'delete_patient',
  LIST_DOCTORS: 'list_doctors',
  CREATE_DOCTOR: 'create_doctor',
  UPDATE_DOCTOR: 'update_doctor',
  DELETE_DOCTOR: 'delete_doctor',
  LIST_APPOINTMENTS: 'list_appointments',
  CREATE_APPOINTMENT: 'create_appointment',
  UPDATE_APPOINTMENT: 'update_appointment',
  DELETE_APPOINTMENT: 'delete_appointment',
  APPROVE_APPOINTMENT: 'approve_appointment',
  LIST_MEDICAL_RECORDS: 'list_medical_records',
  CREATE_MEDICAL_RECORD: 'create_medical_record',
  UPDATE_MEDICAL_RECORD: 'update_medical_record',
  DELETE_MEDICAL_RECORD: 'delete_medical_record',
  REGISTRATION_STATION: 'registration_station',
  MANAGE_USERS: 'manage_users',
};

const ROLE_PERMISSIONS = {
  admin: Object.values(PERMISSIONS),
  doctor: [
    PERMISSIONS.VIEW_DOCTOR_DASHBOARD,
    PERMISSIONS.LIST_PATIENTS,
    PERMISSIONS.LIST_DOCTORS,
    PERMISSIONS.UPDATE_DOCTOR,
    PERMISSIONS.LIST_APPOINTMENTS,
    PERMISSIONS.UPDATE_APPOINTMENT,
    PERMISSIONS.APPROVE_APPOINTMENT,
    PERMISSIONS.LIST_MEDICAL_RECORDS,
    PERMISSIONS.CREATE_MEDICAL_RECORD,
    PERMISSIONS.UPDATE_MEDICAL_RECORD,
  ],
  patient: [
    PERMISSIONS.VIEW_PATIENT_DASHBOARD,
    PERMISSIONS.LIST_DOCTORS,
    PERMISSIONS.LIST_APPOINTMENTS,
    PERMISSIONS.CREATE_APPOINTMENT,
    PERMISSIONS.UPDATE_APPOINTMENT,
    PERMISSIONS.LIST_MEDICAL_RECORDS,
  ],
};

export function getPermissionsForRole(role) {
  return ROLE_PERMISSIONS[role] || [];
}

export function hasPermission(user, permission) {
  if (!user) return false;
  if (Array.isArray(user.permissions) && user.permissions.length) {
    return user.permissions.includes(permission);
  }
  return getPermissionsForRole(user.role).includes(permission);
}

export function hasRole(user, ...roles) {
  if (!user) return false;
  return roles.includes(user.role);
}

export function canAccessRoute(user, roles) {
  if (!user) return false;
  if (!roles || roles.length === 0) return true;
  return roles.includes(user.role);
}
