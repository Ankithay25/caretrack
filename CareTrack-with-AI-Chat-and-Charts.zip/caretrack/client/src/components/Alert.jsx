import { FiCheckCircle, FiAlertCircle, FiInfo, FiX } from 'react-icons/fi';

const Alert = ({ type = 'info', message, onClose }) => {
  if (!message) return null;

  const styles = {
    success: 'bg-green-50 border-green-200 text-green-800',
    error: 'bg-red-50 border-red-200 text-red-800',
    info: 'bg-blue-50 border-blue-200 text-blue-800',
    warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
  };

  const icons = {
    success: <FiCheckCircle className="w-5 h-5" />,
    error: <FiAlertCircle className="w-5 h-5" />,
    info: <FiInfo className="w-5 h-5" />,
    warning: <FiAlertCircle className="w-5 h-5" />,
  };

  return (
    <div className={`flex items-center gap-3 p-4 rounded-lg border ${styles[type]} mb-4`}>
      {icons[type]}
      <span className="flex-1 text-sm">{message}</span>
      {onClose && (
        <button onClick={onClose} className="hover:opacity-70">
          <FiX className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};

export default Alert;
