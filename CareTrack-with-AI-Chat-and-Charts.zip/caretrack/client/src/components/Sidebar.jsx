import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  FiHome,
  FiUsers,
  FiUserCheck,
  FiCalendar,
  FiFileText,
  FiUser,
  FiLogOut,
  FiPlusCircle,
  FiClipboard,
  FiMessageCircle,
  FiBarChart2,
} from 'react-icons/fi';

const Sidebar = ({ isOpen, onClose }) => {
  const { user, logout } = useAuth();

  const adminLinks = [
    { to: '/admin', icon: FiHome, label: 'Dashboard' },
    { to: '/registration-station', icon: FiClipboard, label: 'Registration Station' },
    { to: '/patients', icon: FiUsers, label: 'Patients' },
    { to: '/doctors', icon: FiUserCheck, label: 'Doctors' },
    { to: '/appointments', icon: FiCalendar, label: 'Appointments' },
    { to: '/medical-records', icon: FiFileText, label: 'Medical Records' },
    { to: '/ai-chat', icon: FiMessageCircle, label: 'AI Chat Assistant' },
    { to: '/ai-charts', icon: FiBarChart2, label: 'AI Chart Box' },
    { to: '/profile', icon: FiUser, label: 'Profile' },
  ];

  const doctorLinks = [
    { to: '/doctor', icon: FiHome, label: 'Dashboard' },
    { to: '/patients', icon: FiUsers, label: 'Patients' },
    { to: '/appointments', icon: FiCalendar, label: 'Appointments' },
    { to: '/medical-records', icon: FiFileText, label: 'Medical Records' },
    { to: '/ai-chat', icon: FiMessageCircle, label: 'AI Chat Assistant' },
    { to: '/ai-charts', icon: FiBarChart2, label: 'AI Chart Box' },
    { to: '/profile', icon: FiUser, label: 'Profile' },
  ];

  const patientLinks = [
    { to: '/patient', icon: FiHome, label: 'Dashboard' },
    { to: '/doctors', icon: FiUserCheck, label: 'Doctors' },
    { to: '/book-appointment', icon: FiPlusCircle, label: 'Book Appointment' },
    { to: '/appointments', icon: FiCalendar, label: 'My Appointments' },
    { to: '/medical-records', icon: FiFileText, label: 'Medical Records' },
    { to: '/ai-chat', icon: FiMessageCircle, label: 'AI Chat Assistant' },
    { to: '/profile', icon: FiUser, label: 'Profile' },
  ];

  const links =
    user?.role === 'admin' ? adminLinks : user?.role === 'doctor' ? doctorLinks : patientLinks;

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed top-0 left-0 z-50 h-full w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="p-5 border-b">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">C</span>
              </div>
              <div>
                <h1 className="font-bold text-gray-900">CareTrack</h1>
                <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {links.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`
                }
              >
                <link.icon className="w-5 h-5" />
                {link.label}
              </NavLink>
            ))}
          </nav>

          <div className="p-4 border-t">
            <div className="flex items-center gap-3 mb-3 px-3">
              <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                <span className="text-primary-700 font-semibold text-sm">
                  {user?.name?.charAt(0)?.toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{user?.name}</p>
                <p className="text-xs text-gray-500 truncate">{user?.email}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
            >
              <FiLogOut className="w-5 h-5" />
              Logout
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
