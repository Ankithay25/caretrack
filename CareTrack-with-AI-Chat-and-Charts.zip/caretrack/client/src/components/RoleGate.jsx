import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { hasPermission, hasRole } from '../utils/permissions';
import LoadingSpinner from './LoadingSpinner';

/**
 * Conditionally render children based on role and/or permission.
 *
 * <RoleGate roles={['admin']}>...</RoleGate>
 * <RoleGate permission="create_doctor">...</RoleGate>
 * <RoleGate roles={['admin','doctor']} fallback={null}>...</RoleGate>
 */
const RoleGate = ({
  children,
  roles,
  permission,
  permissions,
  fallback = null,
  redirectTo = null,
}) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <LoadingSpinner />
      </div>
    );
  }

  if (!user) {
    if (redirectTo) return <Navigate to={redirectTo} replace />;
    return fallback;
  }

  let allowed = true;

  if (roles && roles.length) {
    allowed = allowed && hasRole(user, ...roles);
  }

  if (permission) {
    allowed = allowed && hasPermission(user, permission);
  }

  if (permissions && permissions.length) {
    allowed = allowed && permissions.some((p) => hasPermission(user, p));
  }

  if (!allowed) {
    if (redirectTo) return <Navigate to={redirectTo} replace />;
    return fallback;
  }

  return children;
};

export default RoleGate;
