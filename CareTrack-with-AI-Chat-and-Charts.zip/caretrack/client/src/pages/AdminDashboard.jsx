import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import StatCard from '../components/StatCard';
import LoadingSpinner from '../components/LoadingSpinner';
import {
  FiUsers,
  FiUserCheck,
  FiCalendar,
  FiClock,
  FiCheckCircle,
  FiXCircle,
} from 'react-icons/fi';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const { data } = await api.get('/appointments/stats/dashboard');
        setStats(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  const statusBadge = (status) => {
    const map = {
      pending: 'badge-pending',
      approved: 'badge-approved',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled',
      rejected: 'badge-rejected',
    };
    return map[status] || 'badge';
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-500">Overview of your healthcare system</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
        <StatCard title="Total Patients" value={stats?.totalPatients || 0} icon={FiUsers} color="primary" />
        <StatCard title="Total Doctors" value={stats?.totalDoctors || 0} icon={FiUserCheck} color="teal" />
        <StatCard title="Appointments" value={stats?.totalAppointments || 0} icon={FiCalendar} color="purple" />
        <StatCard title="Pending" value={stats?.pendingAppointments || 0} icon={FiClock} color="yellow" />
        <StatCard title="Completed" value={stats?.completedAppointments || 0} icon={FiCheckCircle} color="green" />
        <StatCard title="Cancelled" value={stats?.cancelledAppointments || 0} icon={FiXCircle} color="red" />
      </div>

      {/* Status breakdown */}
      <div className="card mb-8">
        <h2 className="text-lg font-semibold mb-4">Appointment Status Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats?.appointmentsByStatus &&
            Object.entries(stats.appointmentsByStatus).map(([status, count]) => (
              <div key={status} className="text-center p-4 bg-gray-50 rounded-lg">
                <p className="text-2xl font-bold text-gray-900">{count}</p>
                <p className="text-sm text-gray-500 capitalize">{status}</p>
              </div>
            ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Patients */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Patients</h2>
            <Link to="/patients" className="text-sm text-primary-600 hover:underline">
              View all
            </Link>
          </div>
          {stats?.recentPatients?.length > 0 ? (
            <div className="space-y-3">
              {stats.recentPatients.map((p) => (
                <div key={p._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-9 h-9 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-primary-700 font-semibold text-sm">
                      {p.user?.name?.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{p.user?.name}</p>
                    <p className="text-xs text-gray-500 truncate">{p.user?.email}</p>
                  </div>
                  <p className="text-xs text-gray-400">
                    {p.user?.createdAt
                      ? new Date(p.user.createdAt).toLocaleDateString()
                      : ''}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No patients yet</p>
          )}
        </div>

        {/* Recent Appointments */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Appointments</h2>
            <Link to="/appointments" className="text-sm text-primary-600 hover:underline">
              View all
            </Link>
          </div>
          {stats?.recentAppointments?.length > 0 ? (
            <div className="space-y-3">
              {stats.recentAppointments.map((a) => (
                <div key={a._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {a.patient?.user?.name} with {a.doctor?.user?.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(a.date).toLocaleDateString()} at {a.time}
                    </p>
                  </div>
                  <span className={statusBadge(a.status)}>{a.status}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No appointments yet</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
