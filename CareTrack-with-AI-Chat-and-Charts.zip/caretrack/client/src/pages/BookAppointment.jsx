import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Alert from '../components/Alert';
import LoadingSpinner from '../components/LoadingSpinner';

const TIME_SLOTS = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '12:00', '12:30', '14:00', '14:30', '15:00', '15:30',
  '16:00', '16:30', '17:00',
];

const BookAppointment = () => {
  const navigate = useNavigate();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [alert, setAlert] = useState({ type: '', message: '' });
  const [form, setForm] = useState({
    doctorId: '',
    date: '',
    time: '',
    reason: '',
  });

  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        const { data } = await api.get('/doctors', { params: { available: 'true' } });
        setDoctors(data);
      } catch (err) {
        setAlert({ type: 'error', message: 'Failed to load doctors' });
      } finally {
        setLoading(false);
      }
    };
    fetchDoctors();
  }, []);

  const selectedDoctor = doctors.find((d) => d._id === form.doctorId);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.doctorId || !form.date || !form.time) {
      setAlert({ type: 'error', message: 'Please fill all required fields' });
      return;
    }

    setSaving(true);
    try {
      await api.post('/appointments', form);
      setAlert({ type: 'success', message: 'Appointment booked successfully!' });
      setTimeout(() => navigate('/appointments'), 1500);
    } catch (err) {
      setAlert({
        type: 'error',
        message: err.response?.data?.message || 'Failed to book appointment',
      });
    } finally {
      setSaving(false);
    }
  };

  const minDate = new Date().toISOString().split('T')[0];

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Book Appointment</h1>
        <p className="text-gray-500">Schedule a visit with a doctor</p>
      </div>

      <Alert type={alert.type} message={alert.message} onClose={() => setAlert({ type: '', message: '' })} />

      <div className="card">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="label">Select Doctor *</label>
            <select
              className="input"
              value={form.doctorId}
              onChange={(e) => setForm({ ...form, doctorId: e.target.value })}
              required
            >
              <option value="">Choose a doctor</option>
              {doctors.map((d) => (
                <option key={d._id} value={d._id}>
                  Dr. {d.user?.name} — {d.specialization} (${d.consultationFee})
                </option>
              ))}
            </select>
          </div>

          {selectedDoctor && (
            <div className="p-4 bg-primary-50 rounded-lg text-sm">
              <p className="font-medium text-primary-900">
                Dr. {selectedDoctor.user?.name}
              </p>
              <p className="text-primary-700">{selectedDoctor.specialization}</p>
              <p className="text-primary-600">
                {selectedDoctor.qualification} · {selectedDoctor.experience} years experience
              </p>
              <p className="text-primary-600 font-medium mt-1">
                Consultation Fee: ${selectedDoctor.consultationFee}
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Date *</label>
              <input
                type="date"
                className="input"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                min={minDate}
                required
              />
            </div>
            <div>
              <label className="label">Time *</label>
              <select
                className="input"
                value={form.time}
                onChange={(e) => setForm({ ...form, time: e.target.value })}
                required
              >
                <option value="">Select time</option>
                {TIME_SLOTS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="label">Reason for Visit</label>
            <textarea
              className="input"
              rows={3}
              value={form.reason}
              onChange={(e) => setForm({ ...form, reason: e.target.value })}
              placeholder="Describe your symptoms or reason for the appointment..."
            />
          </div>

          <button type="submit" disabled={saving} className="btn-primary w-full">
            {saving ? <LoadingSpinner size="sm" /> : 'Book Appointment'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default BookAppointment;
