import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import StatCard from '../components/StatCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { FiCalendar, FiClock, FiCheckCircle, FiUsers } from 'react-icons/fi';

const DoctorDashboard = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await api.get('/appointments');
        setAppointments(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  const today = new Date().toDateString();
  const todayAppointments = appointments.filter(
    (a) => new Date(a.date).toDateString() === today && a.status !== 'cancelled'
  );
  const pending = appointments.filter((a) => a.status === 'pending');
  const completed = appointments.filter((a) => a.status === 'completed');
  const upcoming = appointments.filter(
    (a) =>
      (a.status === 'approved' || a.status === 'pending') &&
      new Date(a.date) >= new Date(new Date().setHours(0, 0, 0, 0))
  );

  const statusBadge = (status) => {
    const map = {
      pending: 'badge-pending',
      approved: 'badge-approved',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled',
      rejected: 'badge-rejected',
    };
    return map[status] || 'badge';
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Welcome, {user?.name}</h1>
        <p className="text-gray-500">Your practice overview</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Today's Appointments" value={todayAppointments.length} icon={FiCalendar} color="primary" />
        <StatCard title="Pending" value={pending.length} icon={FiClock} color="yellow" />
        <StatCard title="Completed" value={completed.length} icon={FiCheckCircle} color="green" />
        <StatCard title="Upcoming" value={upcoming.length} icon={FiUsers} color="teal" />
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Upcoming Appointments</h2>
          <Link to="/appointments" className="text-sm text-primary-600 hover:underline">
            View all
          </Link>
        </div>

        {upcoming.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-gray-500">
                  <th className="pb-3 font-medium">Patient</th>
                  <th className="pb-3 font-medium">Date</th>
                  <th className="pb-3 font-medium">Time</th>
                  <th className="pb-3 font-medium">Reason</th>
                  <th className="pb-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {upcoming.slice(0, 8).map((a) => (
                  <tr key={a._id} className="border-b border-gray-50">
                    <td className="py-3 font-medium">{a.patient?.user?.name}</td>
                    <td className="py-3">{new Date(a.date).toLocaleDateString()}</td>
                    <td className="py-3">{a.time}</td>
                    <td className="py-3 text-gray-500">{a.reason || '-'}</td>
                    <td className="py-3">
                      <span className={statusBadge(a.status)}>{a.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500 text-sm">No upcoming appointments</p>
        )}
      </div>
    </div>
  );
};

export default DoctorDashboard;
