import { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import Alert from '../components/Alert';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';
import { FiFilter } from 'react-icons/fi';

const Appointments = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [alert, setAlert] = useState({ type: '', message: '' });
  const [recordModal, setRecordModal] = useState(false);
  const [selectedAppt, setSelectedAppt] = useState(null);
  const [saving, setSaving] = useState(false);
  const [recordForm, setRecordForm] = useState({
    diagnosis: '',
    symptoms: '',
    treatment: '',
    notes: '',
    prescriptions: [{ medicine: '', dosage: '', frequency: '', duration: '', instructions: '' }],
  });

  const fetchAppointments = async () => {
    try {
      const params = {};
      if (statusFilter) params.status = statusFilter;
      const { data } = await api.get('/appointments', { params });
      setAppointments(data);
    } catch (err) {
      setAlert({ type: 'error', message: 'Failed to load appointments' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchAppointments();
  }, [statusFilter]);

  const updateStatus = async (id, status) => {
    try {
      await api.put(`/appointments/${id}`, { status });
      setAlert({ type: 'success', message: `Appointment ${status}` });
      fetchAppointments();
    } catch (err) {
      setAlert({ type: 'error', message: err.response?.data?.message || 'Update failed' });
    }
  };

  const openRecordModal = (appt) => {
    setSelectedAppt(appt);
    setRecordForm({
      diagnosis: '',
      symptoms: '',
      treatment: '',
      notes: '',
      prescriptions: [{ medicine: '', dosage: '', frequency: '', duration: '', instructions: '' }],
    });
    setRecordModal(true);
  };

  const handleCreateRecord = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/medical-records', {
        patientId: selectedAppt.patient._id,
        appointmentId: selectedAppt._id,
        ...recordForm,
        prescriptions: recordForm.prescriptions.filter((p) => p.medicine),
      });
      await api.put(`/appointments/${selectedAppt._id}`, { status: 'completed' });
      setAlert({ type: 'success', message: 'Medical record created and appointment completed' });
      setRecordModal(false);
      fetchAppointments();
    } catch (err) {
      setAlert({ type: 'error', message: err.response?.data?.message || 'Failed to create record' });
    } finally {
      setSaving(false);
    }
  };

  const statusBadge = (status) => {
    const map = {
      pending: 'badge-pending',
      approved: 'badge-approved',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled',
      rejected: 'badge-rejected',
    };
    return map[status] || 'badge';
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Appointments</h1>
        <p className="text-gray-500">Manage and track appointments</p>
      </div>

      <Alert type={alert.type} message={alert.message} onClose={() => setAlert({ type: '', message: '' })} />

      <div className="card mb-6">
        <div className="flex items-center gap-3">
          <FiFilter className="text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="input max-w-xs"
          >
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <LoadingSpinner size="lg" />
        </div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-gray-500">
                {user?.role !== 'patient' && <th className="pb-3 font-medium">Patient</th>}
                {user?.role !== 'doctor' && <th className="pb-3 font-medium">Doctor</th>}
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium">Time</th>
                <th className="pb-3 font-medium">Reason</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {appointments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-gray-500">
                    No appointments found
                  </td>
                </tr>
              ) : (
                appointments.map((a) => (
                  <tr key={a._id} className="border-b border-gray-50 hover:bg-gray-50">
                    {user?.role !== 'patient' && (
                      <td className="py-3 font-medium">{a.patient?.user?.name}</td>
                    )}
                    {user?.role !== 'doctor' && (
                      <td className="py-3">
                        <div>
                          <p className="font-medium">Dr. {a.doctor?.user?.name}</p>
                          <p className="text-xs text-gray-500">{a.doctor?.specialization}</p>
                        </div>
                      </td>
                    )}
                    <td className="py-3">{new Date(a.date).toLocaleDateString()}</td>
                    <td className="py-3">{a.time}</td>
                    <td className="py-3 text-gray-600 max-w-[150px] truncate">
                      {a.reason || '-'}
                    </td>
                    <td className="py-3">
                      <span className={statusBadge(a.status)}>{a.status}</span>
                    </td>
                    <td className="py-3">
                      <div className="flex flex-wrap gap-1">
                        {(user?.role === 'admin' || user?.role === 'doctor') &&
                          a.status === 'pending' && (
                            <>
                              <button
                                onClick={() => updateStatus(a._id, 'approved')}
                                className="text-xs px-2 py-1 bg-blue-50 text-blue-700 rounded hover:bg-blue-100"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => updateStatus(a._id, 'rejected')}
                                className="text-xs px-2 py-1 bg-red-50 text-red-700 rounded hover:bg-red-100"
                              >
                                Reject
                              </button>
                            </>
                          )}
                        {user?.role === 'doctor' && a.status === 'approved' && (
                          <button
                            onClick={() => openRecordModal(a)}
                            className="text-xs px-2 py-1 bg-green-50 text-green-700 rounded hover:bg-green-100"
                          >
                            Complete & Record
                          </button>
                        )}
                        {user?.role === 'patient' &&
                          (a.status === 'pending' || a.status === 'approved') && (
                            <button
                              onClick={() => updateStatus(a._id, 'cancelled')}
                              className="text-xs px-2 py-1 bg-red-50 text-red-700 rounded hover:bg-red-100"
                            >
                              Cancel
                            </button>
                          )}
                        {user?.role === 'admin' && a.status === 'approved' && (
                          <button
                            onClick={() => updateStatus(a._id, 'completed')}
                            className="text-xs px-2 py-1 bg-green-50 text-green-700 rounded hover:bg-green-100"
                          >
                            Complete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Medical Record Modal for doctors */}
      <Modal
        isOpen={recordModal}
        onClose={() => setRecordModal(false)}
        title="Create Medical Record"
        size="lg"
      >
        <form onSubmit={handleCreateRecord} className="space-y-4">
          <p className="text-sm text-gray-500">
            Patient: <strong>{selectedAppt?.patient?.user?.name}</strong>
          </p>
          <div>
            <label className="label">Diagnosis *</label>
            <input
              type="text"
              className="input"
              value={recordForm.diagnosis}
              onChange={(e) => setRecordForm({ ...recordForm, diagnosis: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="label">Symptoms</label>
            <textarea
              className="input"
              rows={2}
              value={recordForm.symptoms}
              onChange={(e) => setRecordForm({ ...recordForm, symptoms: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Treatment</label>
            <textarea
              className="input"
              rows={2}
              value={recordForm.treatment}
              onChange={(e) => setRecordForm({ ...recordForm, treatment: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Notes</label>
            <textarea
              className="input"
              rows={2}
              value={recordForm.notes}
              onChange={(e) => setRecordForm({ ...recordForm, notes: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Prescription</label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                className="input"
                placeholder="Medicine"
                value={recordForm.prescriptions[0].medicine}
                onChange={(e) =>
                  setRecordForm({
                    ...recordForm,
                    prescriptions: [
                      { ...recordForm.prescriptions[0], medicine: e.target.value },
                    ],
                  })
                }
              />
              <input
                type="text"
                className="input"
                placeholder="Dosage"
                value={recordForm.prescriptions[0].dosage}
                onChange={(e) =>
                  setRecordForm({
                    ...recordForm,
                    prescriptions: [
                      { ...recordForm.prescriptions[0], dosage: e.target.value },
                    ],
                  })
                }
              />
              <input
                type="text"
                className="input"
                placeholder="Frequency"
                value={recordForm.prescriptions[0].frequency}
                onChange={(e) =>
                  setRecordForm({
                    ...recordForm,
                    prescriptions: [
                      { ...recordForm.prescriptions[0], frequency: e.target.value },
                    ],
                  })
                }
              />
              <input
                type="text"
                className="input"
                placeholder="Duration"
                value={recordForm.prescriptions[0].duration}
                onChange={(e) =>
                  setRecordForm({
                    ...recordForm,
                    prescriptions: [
                      { ...recordForm.prescriptions[0], duration: e.target.value },
                    ],
                  })
                }
              />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setRecordModal(false)} className="btn-secondary">
              Cancel
            </button>
            <button type="submit" disabled={saving} className="btn-success">
              {saving ? <LoadingSpinner size="sm" /> : 'Save & Complete'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Appointments;
