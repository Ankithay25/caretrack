import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import StatCard from '../components/StatCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { FiCalendar, FiClock, FiCheckCircle, FiPlusCircle } from 'react-icons/fi';

const PatientDashboard = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [apptRes, recordsRes] = await Promise.all([
          api.get('/appointments'),
          api.get('/medical-records'),
        ]);
        setAppointments(apptRes.data);
        setRecords(recordsRes.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  const pending = appointments.filter((a) => a.status === 'pending');
  const upcoming = appointments.filter(
    (a) =>
      (a.status === 'approved' || a.status === 'pending') &&
      new Date(a.date) >= new Date(new Date().setHours(0, 0, 0, 0))
  );
  const completed = appointments.filter((a) => a.status === 'completed');

  const statusBadge = (status) => {
    const map = {
      pending: 'badge-pending',
      approved: 'badge-approved',
      completed: 'badge-completed',
      cancelled: 'badge-cancelled',
      rejected: 'badge-rejected',
    };
    return map[status] || 'badge';
  };

  return (
    <div>
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Welcome, {user?.name}</h1>
          <p className="text-gray-500">Manage your health appointments</p>
        </div>
        <Link to="/book-appointment" className="btn-primary inline-flex items-center gap-2">
          <FiPlusCircle className="w-4 h-4" />
          Book Appointment
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Upcoming" value={upcoming.length} icon={FiCalendar} color="primary" />
        <StatCard title="Pending" value={pending.length} icon={FiClock} color="yellow" />
        <StatCard title="Completed" value={completed.length} icon={FiCheckCircle} color="green" />
        <StatCard title="Medical Records" value={records.length} icon={FiPlusCircle} color="teal" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Upcoming Appointments</h2>
            <Link to="/appointments" className="text-sm text-primary-600 hover:underline">
              View all
            </Link>
          </div>
          {upcoming.length > 0 ? (
            <div className="space-y-3">
              {upcoming.slice(0, 5).map((a) => (
                <div key={a._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">Dr. {a.doctor?.user?.name}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(a.date).toLocaleDateString()} at {a.time}
                    </p>
                    {a.doctor?.specialization && (
                      <p className="text-xs text-primary-600">{a.doctor.specialization}</p>
                    )}
                  </div>
                  <span className={statusBadge(a.status)}>{a.status}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No upcoming appointments</p>
          )}
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recent Medical Records</h2>
            <Link to="/medical-records" className="text-sm text-primary-600 hover:underline">
              View all
            </Link>
          </div>
          {records.length > 0 ? (
            <div className="space-y-3">
              {records.slice(0, 5).map((r) => (
                <div key={r._id} className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm font-medium">{r.diagnosis}</p>
                  <p className="text-xs text-gray-500">
                    Dr. {r.doctor?.user?.name} —{' '}
                    {new Date(r.recordDate).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No medical records yet</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;
