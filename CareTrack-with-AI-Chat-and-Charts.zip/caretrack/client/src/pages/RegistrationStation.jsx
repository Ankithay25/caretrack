import { useState } from 'react';
import api from '../services/api';
import Alert from '../components/Alert';
import LoadingSpinner from '../components/LoadingSpinner';
import { FiUserPlus, FiUserCheck } from 'react-icons/fi';

const RegistrationStation = () => {
  const [tab, setTab] = useState('patient');
  const [alert, setAlert] = useState({ type: '', message: '' });
  const [saving, setSaving] = useState(false);

  const [patientForm, setPatientForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    gender: '',
    dateOfBirth: '',
    address: '',
    bloodGroup: '',
    notes: '',
  });

  const [doctorForm, setDoctorForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    gender: '',
    specialization: '',
    qualification: '',
    experience: 0,
    consultationFee: 50,
    department: '',
    licenseNumber: '',
    bio: '',
  });

  const resetPatient = () =>
    setPatientForm({
      name: '',
      email: '',
      password: '',
      phone: '',
      gender: '',
      dateOfBirth: '',
      address: '',
      bloodGroup: '',
      notes: '',
    });

  const resetDoctor = () =>
    setDoctorForm({
      name: '',
      email: '',
      password: '',
      phone: '',
      gender: '',
      specialization: '',
      qualification: '',
      experience: 0,
      consultationFee: 50,
      department: '',
      licenseNumber: '',
      bio: '',
    });

  const handlePatientSubmit = async (e) => {
    e.preventDefault();
    setAlert({ type: '', message: '' });
    setSaving(true);
    try {
      await api.post('/patients', patientForm);
      setAlert({
        type: 'success',
        message: `Patient "${patientForm.name}" registered successfully. They can log in with their email and password.`,
      });
      resetPatient();
    } catch (err) {
      setAlert({
        type: 'error',
        message: err.response?.data?.message || 'Patient registration failed',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDoctorSubmit = async (e) => {
    e.preventDefault();
    setAlert({ type: '', message: '' });
    setSaving(true);
    try {
      await api.post('/doctors', doctorForm);
      setAlert({
        type: 'success',
        message: `Doctor "${doctorForm.name}" registered successfully. They can log in with their email and password.`,
      });
      resetDoctor();
    } catch (err) {
      setAlert({
        type: 'error',
        message: err.response?.data?.message || 'Doctor registration failed',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Registration Station</h1>
        <p className="text-gray-500">
          Register new patients or doctors from the front desk. Accounts are created in the system immediately.
        </p>
      </div>

      <Alert
        type={alert.type}
        message={alert.message}
        onClose={() => setAlert({ type: '', message: '' })}
      />

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        <button
          type="button"
          onClick={() => {
            setTab('patient');
            setAlert({ type: '', message: '' });
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            tab === 'patient'
              ? 'bg-primary-600 text-white'
              : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <FiUserPlus className="w-4 h-4" />
          Register Patient
        </button>
        <button
          type="button"
          onClick={() => {
            setTab('doctor');
            setAlert({ type: '', message: '' });
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
            tab === 'doctor'
              ? 'bg-teal-600 text-white'
              : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          <FiUserCheck className="w-4 h-4" />
          Register Doctor
        </button>
      </div>

      {/* Patient form */}
      {tab === 'patient' && (
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">New Patient Registration</h2>
          <form onSubmit={handlePatientSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="label">Full Name *</label>
                <input
                  type="text"
                  className="input"
                  value={patientForm.name}
                  onChange={(e) => setPatientForm({ ...patientForm, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className="label">Email *</label>
                <input
                  type="email"
                  className="input"
                  value={patientForm.email}
                  onChange={(e) => setPatientForm({ ...patientForm, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className="label">Password *</label>
                <input
                  type="password"
                  className="input"
                  value={patientForm.password}
                  onChange={(e) => setPatientForm({ ...patientForm, password: e.target.value })}
                  required
                  minLength={6}
                  placeholder="Min 6 characters"
                />
              </div>
              <div>
                <label className="label">Phone</label>
                <input
                  type="tel"
                  className="input"
                  value={patientForm.phone}
                  onChange={(e) => setPatientForm({ ...patientForm, phone: e.target.value })}
                />
              </div>
              <div>
                <label className="label">Gender</label>
                <select
                  className="input"
                  value={patientForm.gender}
                  onChange={(e) => setPatientForm({ ...patientForm, gender: e.target.value })}
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="label">Date of Birth</label>
                <input
                  type="date"
                  className="input"
                  value={patientForm.dateOfBirth}
                  onChange={(e) => setPatientForm({ ...patientForm, dateOfBirth: e.target.value })}
                />
              </div>
              <div>
                <label className="label">Blood Group</label>
                <select
                  className="input"
                  value={patientForm.bloodGroup}
                  onChange={(e) => setPatientForm({ ...patientForm, bloodGroup: e.target.value })}
                >
                  <option value="">Select</option>
                  {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="label">Address</label>
                <input
                  type="text"
                  className="input"
                  value={patientForm.address}
                  onChange={(e) => setPatientForm({ ...patientForm, address: e.target.value })}
                />
              </div>
              <div className="md:col-span-2">
                <label className="label">Notes</label>
                <textarea
                  className="input"
                  rows={2}
                  value={patientForm.notes}
                  onChange={(e) => setPatientForm({ ...patientForm, notes: e.target.value })}
                  placeholder="Allergies, emergency contact, etc."
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={resetPatient} className="btn-secondary">
                Clear
              </button>
              <button type="submit" disabled={saving} className="btn-primary">
                {saving ? <LoadingSpinner size="sm" /> : 'Register Patient'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Doctor form */}
      {tab === 'doctor' && (
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">New Doctor Registration</h2>
          <form onSubmit={handleDoctorSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="label">Full Name *</label>
                <input
                  type="text"
                  className="input"
                  value={doctorForm.name}
                  onChange={(e) => setDoctorForm({ ...doctorForm, name: e.target.value })}
                  required
                  placeholder="Dr. Full Name"
                />
              </div>
              <div>
                <label className="label">Email *</label>
                <input
                  type="email"
                  className="input"
                  value={doctorForm.email}
                  onChange={(e) => setDoctorForm({ ...doctorForm, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className="label">Password *</label>
                <input
                  type="password"
                  className="input"
                  value={doctorForm.password}
                  onChange={(e) => setDoctorForm({ ...doctorForm, password: e.target.value })}
                  required
                  minLength={6}
                  placeholder="Min 6 characters"
                />
              </div>
              <div>
                <label className="label">Phone</label>
                <input
                  type="tel"
                  className="input"
                  value={doctorForm.phone}
                  onChange={(e) => setDoctorForm({ ...doctorForm, phone: e.target.value })}
                />
              </div>
              <div>
                <label className="label">Gender</label>
                <select
                  className="input"
                  value={doctorForm.gender}
                  onChange={(e) => setDoctorForm({ ...doctorForm, gender: e.target.value })}
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="label">Specialization *</label>
                <input
                  type="text"
                  className="input"
                  value={doctorForm.specialization}
                  onChange={(e) => setDoctorForm({ ...doctorForm, specialization: e.target.value })}
                  required
                  placeholder="e.g. Cardiology"
                />
              </div>
              <div>
                <label className="label">Qualification</label>
                <input
                  type="text"
                  className="input"
                  value={doctorForm.qualification}
                  onChange={(e) => setDoctorForm({ ...doctorForm, qualification: e.target.value })}
                  placeholder="e.g. MBBS, MD"
                />
              </div>
              <div>
                <label className="label">Experience (years)</label>
                <input
                  type="number"
                  className="input"
                  value={doctorForm.experience}
                  onChange={(e) =>
                    setDoctorForm({ ...doctorForm, experience: Number(e.target.value) })
                  }
                  min={0}
                />
              </div>
              <div>
                <label className="label">Consultation Fee ($) *</label>
                <input
                  type="number"
                  className="input"
                  value={doctorForm.consultationFee}
                  onChange={(e) =>
                    setDoctorForm({ ...doctorForm, consultationFee: Number(e.target.value) })
                  }
                  required
                  min={0}
                />
              </div>
              <div>
                <label className="label">Department</label>
                <input
                  type="text"
                  className="input"
                  value={doctorForm.department}
                  onChange={(e) => setDoctorForm({ ...doctorForm, department: e.target.value })}
                />
              </div>
              <div>
                <label className="label">License Number</label>
                <input
                  type="text"
                  className="input"
                  value={doctorForm.licenseNumber}
                  onChange={(e) => setDoctorForm({ ...doctorForm, licenseNumber: e.target.value })}
                />
              </div>
              <div className="md:col-span-2">
                <label className="label">Bio</label>
                <textarea
                  className="input"
                  rows={2}
                  value={doctorForm.bio}
                  onChange={(e) => setDoctorForm({ ...doctorForm, bio: e.target.value })}
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button type="button" onClick={resetDoctor} className="btn-secondary">
                Clear
              </button>
              <button type="submit" disabled={saving} className="btn-success">
                {saving ? <LoadingSpinner size="sm" /> : 'Register Doctor'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default RegistrationStation;
