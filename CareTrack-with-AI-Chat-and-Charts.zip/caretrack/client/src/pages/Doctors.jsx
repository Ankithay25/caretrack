import { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import Modal from '../components/Modal';
import Alert from '../components/Alert';
import LoadingSpinner from '../components/LoadingSpinner';
import { FiPlus, FiEdit2, FiTrash2, FiSearch } from 'react-icons/fi';

const Doctors = () => {
  const { user } = useAuth();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [alert, setAlert] = useState({ type: '', message: '' });
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    gender: '',
    specialization: '',
    qualification: '',
    experience: 0,
    consultationFee: 0,
    department: '',
    licenseNumber: '',
    bio: '',
  });

  const fetchDoctors = async () => {
    try {
      const { data } = await api.get('/doctors', { params: { search } });
      setDoctors(data);
    } catch (err) {
      setAlert({ type: 'error', message: 'Failed to load doctors' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(true);
      fetchDoctors();
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  const openCreate = () => {
    setEditing(null);
    setForm({
      name: '',
      email: '',
      password: '',
      phone: '',
      gender: '',
      specialization: '',
      qualification: '',
      experience: 0,
      consultationFee: 50,
      department: '',
      licenseNumber: '',
      bio: '',
    });
    setModalOpen(true);
  };

  const openEdit = (doctor) => {
    setEditing(doctor);
    setForm({
      name: doctor.user?.name || '',
      email: doctor.user?.email || '',
      password: '',
      phone: doctor.user?.phone || '',
      gender: doctor.user?.gender || '',
      specialization: doctor.specialization || '',
      qualification: doctor.qualification || '',
      experience: doctor.experience || 0,
      consultationFee: doctor.consultationFee || 0,
      department: doctor.department || '',
      licenseNumber: doctor.licenseNumber || '',
      bio: doctor.bio || '',
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await api.put(`/doctors/${editing._id}`, form);
        setAlert({ type: 'success', message: 'Doctor updated successfully' });
      } else {
        await api.post('/doctors', form);
        setAlert({ type: 'success', message: 'Doctor created successfully' });
      }
      setModalOpen(false);
      fetchDoctors();
    } catch (err) {
      setAlert({
        type: 'error',
        message: err.response?.data?.message || 'Operation failed',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to remove this doctor?')) return;
    try {
      await api.delete(`/doctors/${id}`);
      setAlert({ type: 'success', message: 'Doctor removed' });
      fetchDoctors();
    } catch (err) {
      setAlert({ type: 'error', message: err.response?.data?.message || 'Delete failed' });
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Doctors</h1>
          <p className="text-gray-500">
            {user?.role === 'admin' ? 'Manage doctors' : 'Browse available doctors'}
          </p>
        </div>
        {user?.role === 'admin' && (
          <button onClick={openCreate} className="btn-primary inline-flex items-center gap-2">
            <FiPlus className="w-4 h-4" />
            Add Doctor
          </button>
        )}
      </div>

      <Alert type={alert.type} message={alert.message} onClose={() => setAlert({ type: '', message: '' })} />

      <div className="card mb-6">
        <div className="relative">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search by name or specialization..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input pl-10"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <LoadingSpinner size="lg" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {doctors.length === 0 ? (
            <div className="col-span-full text-center py-12 text-gray-500">No doctors found</div>
          ) : (
            doctors.map((d) => (
              <div key={d._id} className="card hover:shadow-md transition-shadow">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-teal-700 font-bold text-lg">
                      {d.user?.name?.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">
                      Dr. {d.user?.name}
                    </h3>
                    <p className="text-sm text-primary-600">{d.specialization}</p>
                    <p className="text-xs text-gray-500 mt-1">{d.qualification}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                      <span>{d.experience} yrs exp</span>
                      <span className="font-medium text-teal-600">${d.consultationFee}</span>
                    </div>
                    {d.department && (
                      <p className="text-xs text-gray-400 mt-1">{d.department}</p>
                    )}
                    <div className="mt-2">
                      <span
                        className={`badge ${
                          d.isAvailable ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {d.isAvailable ? 'Available' : 'Unavailable'}
                      </span>
                    </div>
                  </div>
                </div>
                {user?.role === 'admin' && (
                  <div className="flex gap-2 mt-4 pt-3 border-t">
                    <button
                      onClick={() => openEdit(d)}
                      className="btn-outline flex-1 text-sm py-1.5 inline-flex items-center justify-center gap-1"
                    >
                      <FiEdit2 className="w-3.5 h-3.5" /> Edit
                    </button>
                    <button
                      onClick={() => handleDelete(d._id)}
                      className="btn-danger flex-1 text-sm py-1.5 inline-flex items-center justify-center gap-1"
                    >
                      <FiTrash2 className="w-3.5 h-3.5" /> Remove
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Doctor' : 'Add Doctor'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Full Name *</label>
              <input
                type="text"
                className="input"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="label">Email *</label>
              <input
                type="email"
                className="input"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
                disabled={!!editing}
              />
            </div>
            {!editing && (
              <div>
                <label className="label">Password *</label>
                <input
                  type="password"
                  className="input"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  required
                  minLength={6}
                />
              </div>
            )}
            <div>
              <label className="label">Phone</label>
              <input
                type="tel"
                className="input"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </div>
            <div>
              <label className="label">Specialization *</label>
              <input
                type="text"
                className="input"
                value={form.specialization}
                onChange={(e) => setForm({ ...form, specialization: e.target.value })}
                required
                placeholder="e.g. Cardiology"
              />
            </div>
            <div>
              <label className="label">Qualification</label>
              <input
                type="text"
                className="input"
                value={form.qualification}
                onChange={(e) => setForm({ ...form, qualification: e.target.value })}
                placeholder="e.g. MBBS, MD"
              />
            </div>
            <div>
              <label className="label">Experience (years)</label>
              <input
                type="number"
                className="input"
                value={form.experience}
                onChange={(e) => setForm({ ...form, experience: Number(e.target.value) })}
                min={0}
              />
            </div>
            <div>
              <label className="label">Consultation Fee ($) *</label>
              <input
                type="number"
                className="input"
                value={form.consultationFee}
                onChange={(e) => setForm({ ...form, consultationFee: Number(e.target.value) })}
                required
                min={0}
              />
            </div>
            <div>
              <label className="label">Department</label>
              <input
                type="text"
                className="input"
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
              />
            </div>
            <div>
              <label className="label">License Number</label>
              <input
                type="text"
                className="input"
                value={form.licenseNumber}
                onChange={(e) => setForm({ ...form, licenseNumber: e.target.value })}
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Bio</label>
              <textarea
                className="input"
                rows={2}
                value={form.bio}
                onChange={(e) => setForm({ ...form, bio: e.target.value })}
              />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary">
              Cancel
            </button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving ? <LoadingSpinner size="sm" /> : editing ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Doctors;
