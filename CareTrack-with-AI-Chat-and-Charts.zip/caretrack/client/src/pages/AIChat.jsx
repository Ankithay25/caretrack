import { useState } from 'react';
import { FiMessageCircle, FiSend, FiCpu } from 'react-icons/fi';
import api from '../services/api';

export default function AIChat() {
  const [messages, setMessages] = useState([{ role: 'assistant', content: 'Hello! I am CareTrack Assistant. I can share general health information and help you understand how to use CareTrack. I cannot diagnose conditions or replace a healthcare professional.' }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const send = async (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || loading) return;
    const next = [...messages, { role: 'user', content: text }];
    setMessages(next); setInput(''); setLoading(true);
    try {
      const { data } = await api.post('/ai/chat', { messages: next.slice(-12).map(({ role, content }) => ({ role, content })) });
      setMessages((current) => [...current, { role: 'assistant', content: data.reply }]);
    } catch (err) {
      setMessages((current) => [...current, { role: 'assistant', content: err.response?.data?.message || 'I could not connect to the assistant. Please check that the CareTrack server is running.' }]);
    } finally { setLoading(false); }
  };
  return <div className="max-w-4xl mx-auto space-y-5">
    <div><p className="text-sm font-semibold text-primary-600">CARETRACK AI</p><h1 className="text-2xl font-bold text-gray-900">AI Chat Assistant</h1><p className="text-gray-500 mt-1">Ask general health and CareTrack questions.</p></div>
    <div className="bg-white border rounded-2xl shadow-sm flex flex-col h-[65vh] min-h-[440px]">
      <div className="p-4 border-b flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-700 flex items-center justify-center"><FiMessageCircle size={21}/></div><div><p className="font-semibold">CareTrack Assistant</p><p className="text-xs text-green-600">● Ready to help</p></div></div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">{messages.map((m,i)=><div key={i} className={`flex ${m.role==='user'?'justify-end':'justify-start'}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap ${m.role==='user'?'bg-primary-600 text-white':'bg-gray-100 text-gray-800'}`}>{m.content}</div></div>)}{loading&&<p className="text-sm text-gray-400">Assistant is thinking…</p>}</div>
      <form onSubmit={send} className="p-3 border-t flex gap-2"><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Type your question…" className="flex-1 border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"/><button disabled={loading||!input.trim()} className="bg-primary-600 text-white rounded-xl px-4 disabled:opacity-50" aria-label="Send message"><FiSend/></button></form>
    </div>
    <p className="text-xs text-gray-500 flex gap-2"><FiCpu className="shrink-0"/> Health information is general and may not be accurate for your situation. For emergencies, contact local emergency services. Do not enter passwords or highly sensitive personal/medical information.</p>
  </div>;
}
