import { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import Alert from '../components/Alert';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';
import { FiEye, FiFileText } from 'react-icons/fi';

const MedicalRecords = () => {
  const { user } = useAuth();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [alert, setAlert] = useState({ type: '', message: '' });
  const [selected, setSelected] = useState(null);
  const [viewModal, setViewModal] = useState(false);

  useEffect(() => {
    const fetchRecords = async () => {
      try {
        const { data } = await api.get('/medical-records');
        setRecords(data);
      } catch (err) {
        setAlert({ type: 'error', message: 'Failed to load medical records' });
      } finally {
        setLoading(false);
      }
    };
    fetchRecords();
  }, []);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Medical Records</h1>
        <p className="text-gray-500">
          {user?.role === 'patient'
            ? 'Your medical history and prescriptions'
            : 'Patient medical records'}
        </p>
      </div>

      <Alert type={alert.type} message={alert.message} onClose={() => setAlert({ type: '', message: '' })} />

      {loading ? (
        <div className="flex justify-center py-12">
          <LoadingSpinner size="lg" />
        </div>
      ) : records.length === 0 ? (
        <div className="card text-center py-12">
          <FiFileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No medical records found</p>
        </div>
      ) : (
        <div className="space-y-4">
          {records.map((r) => (
            <div key={r._id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{r.diagnosis}</h3>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
                    {user?.role !== 'patient' && (
                      <span>Patient: {r.patient?.user?.name}</span>
                    )}
                    {user?.role !== 'doctor' && (
                      <span>Dr. {r.doctor?.user?.name}</span>
                    )}
                    <span>{new Date(r.recordDate).toLocaleDateString()}</span>
                  </div>
                  {r.treatment && (
                    <p className="text-sm text-gray-600 mt-2 line-clamp-2">{r.treatment}</p>
                  )}
                  {r.prescriptions?.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {r.prescriptions.map((p, i) => (
                        <span key={i} className="badge bg-teal-50 text-teal-700">
                          {p.medicine}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => {
                    setSelected(r);
                    setViewModal(true);
                  }}
                  className="btn-outline text-sm py-1.5 px-3 inline-flex items-center gap-1 flex-shrink-0"
                >
                  <FiEye className="w-3.5 h-3.5" /> View
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={viewModal} onClose={() => setViewModal(false)} title="Medical Record Details" size="lg">
        {selected && (
          <div className="space-y-4 text-sm">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-gray-500">Patient</p>
                <p className="font-medium">{selected.patient?.user?.name}</p>
              </div>
              <div>
                <p className="text-gray-500">Doctor</p>
                <p className="font-medium">Dr. {selected.doctor?.user?.name}</p>
              </div>
              <div>
                <p className="text-gray-500">Date</p>
                <p className="font-medium">
                  {new Date(selected.recordDate).toLocaleDateString()}
                </p>
              </div>
              {selected.followUpDate && (
                <div>
                  <p className="text-gray-500">Follow-up</p>
                  <p className="font-medium">
                    {new Date(selected.followUpDate).toLocaleDateString()}
                  </p>
                </div>
              )}
            </div>

            <div>
              <p className="text-gray-500">Diagnosis</p>
              <p className="font-medium">{selected.diagnosis}</p>
            </div>

            {selected.symptoms && (
              <div>
                <p className="text-gray-500">Symptoms</p>
                <p>{selected.symptoms}</p>
              </div>
            )}

            {selected.treatment && (
              <div>
                <p className="text-gray-500">Treatment</p>
                <p>{selected.treatment}</p>
              </div>
            )}

            {selected.notes && (
              <div>
                <p className="text-gray-500">Doctor Notes</p>
                <p>{selected.notes}</p>
              </div>
            )}

            {selected.prescriptions?.length > 0 && (
              <div>
                <p className="text-gray-500 mb-2">Prescriptions</p>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border rounded-lg overflow-hidden">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left">Medicine</th>
                        <th className="px-3 py-2 text-left">Dosage</th>
                        <th className="px-3 py-2 text-left">Frequency</th>
                        <th className="px-3 py-2 text-left">Duration</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selected.prescriptions.map((p, i) => (
                        <tr key={i} className="border-t">
                          <td className="px-3 py-2 font-medium">{p.medicine}</td>
                          <td className="px-3 py-2">{p.dosage}</td>
                          <td className="px-3 py-2">{p.frequency}</td>
                          <td className="px-3 py-2">{p.duration}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {selected.vitalSigns && Object.values(selected.vitalSigns).some(Boolean) && (
              <div>
                <p className="text-gray-500 mb-2">Vital Signs</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {selected.vitalSigns.bloodPressure && (
                    <div className="bg-gray-50 p-2 rounded">
                      <p className="text-xs text-gray-500">Blood Pressure</p>
                      <p className="font-medium">{selected.vitalSigns.bloodPressure}</p>
                    </div>
                  )}
                  {selected.vitalSigns.heartRate && (
                    <div className="bg-gray-50 p-2 rounded">
                      <p className="text-xs text-gray-500">Heart Rate</p>
                      <p className="font-medium">{selected.vitalSigns.heartRate}</p>
                    </div>
                  )}
                  {selected.vitalSigns.temperature && (
                    <div className="bg-gray-50 p-2 rounded">
                      <p className="text-xs text-gray-500">Temperature</p>
                      <p className="font-medium">{selected.vitalSigns.temperature}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MedicalRecords;
