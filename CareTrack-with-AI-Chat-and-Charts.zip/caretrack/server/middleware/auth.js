const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { roleHasPermission, getPermissionsForRole } = require('../config/permissions');

const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');

      if (!req.user) {
        return res.status(401).json({ message: 'User not found' });
      }

      if (!req.user.isActive) {
        return res.status(401).json({ message: 'Account has been deactivated' });
      }

      req.userPermissions = getPermissionsForRole(req.user.role);
      return next();
    } catch (error) {
      console.error(error);
      return res.status(401).json({ message: 'Not authorized, token failed' });
    }
  }

  return res.status(401).json({ message: 'Not authorized, no token' });
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        message: `Access denied. Required role: ${roles.join(' or ')}. Your role: ${req.user?.role || 'none'}`,
      });
    }
    next();
  };
};

const requirePermission = (...permissions) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    const allowed = permissions.some((p) => roleHasPermission(req.user.role, p));
    if (!allowed) {
      return res.status(403).json({
        message: `Permission denied. Need one of: ${permissions.join(', ')}`,
        role: req.user.role,
      });
    }
    next();
  };
};

module.exports = { protect, authorize, requirePermission };
