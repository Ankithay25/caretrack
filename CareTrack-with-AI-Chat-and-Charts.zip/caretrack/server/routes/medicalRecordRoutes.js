const express = require('express');
const {
  getMedicalRecords,
  getMedicalRecord,
  createMedicalRecord,
  updateMedicalRecord,
  deleteMedicalRecord,
} = require('../controllers/medicalRecordController');
const { protect, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();

router.use(protect);

router.get('/', requirePermission(PERMISSIONS.LIST_MEDICAL_RECORDS), getMedicalRecords);
router.post('/', requirePermission(PERMISSIONS.CREATE_MEDICAL_RECORD), createMedicalRecord);
router.get('/:id', requirePermission(PERMISSIONS.LIST_MEDICAL_RECORDS), getMedicalRecord);
router.put('/:id', requirePermission(PERMISSIONS.UPDATE_MEDICAL_RECORD), updateMedicalRecord);
router.delete('/:id', requirePermission(PERMISSIONS.DELETE_MEDICAL_RECORD), deleteMedicalRecord);

module.exports = router;
