const express = require('express');
const {
  getPatients,
  getPatient,
  createPatient,
  updatePatient,
  deletePatient,
  getPatientAppointments,
  getMyPatientProfile,
} = require('../controllers/patientController');
const { protect, authorize, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();

router.use(protect);

router.get('/me/profile', authorize('patient'), getMyPatientProfile);
router.get('/', requirePermission(PERMISSIONS.LIST_PATIENTS), getPatients);
router.post('/', requirePermission(PERMISSIONS.CREATE_PATIENT), createPatient);
router.get('/:id', requirePermission(PERMISSIONS.VIEW_PATIENT), getPatient);
router.put('/:id', requirePermission(PERMISSIONS.UPDATE_PATIENT), updatePatient);
router.delete('/:id', requirePermission(PERMISSIONS.DELETE_PATIENT), deletePatient);
router.get('/:id/appointments', protect, getPatientAppointments);

module.exports = router;
