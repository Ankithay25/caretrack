const express = require('express');
const {
  getAppointments,
  getAppointment,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  getDashboardStats,
} = require('../controllers/appointmentController');
const { protect, authorize, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();

router.use(protect);

router.get('/stats/dashboard', requirePermission(PERMISSIONS.VIEW_ADMIN_DASHBOARD), getDashboardStats);
router.get('/', requirePermission(PERMISSIONS.LIST_APPOINTMENTS), getAppointments);
router.post('/', requirePermission(PERMISSIONS.CREATE_APPOINTMENT), createAppointment);
router.get('/:id', requirePermission(PERMISSIONS.LIST_APPOINTMENTS), getAppointment);
router.put('/:id', requirePermission(PERMISSIONS.UPDATE_APPOINTMENT), updateAppointment);
router.delete('/:id', requirePermission(PERMISSIONS.DELETE_APPOINTMENT), deleteAppointment);

module.exports = router;
