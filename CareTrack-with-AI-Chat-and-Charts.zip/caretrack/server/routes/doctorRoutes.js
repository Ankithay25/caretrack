const express = require('express');
const {
  getDoctors,
  getDoctor,
  createDoctor,
  updateDoctor,
  deleteDoctor,
  getDoctorAppointments,
  getMyDoctorProfile,
} = require('../controllers/doctorController');
const { protect, authorize, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../config/permissions');

const router = express.Router();

// Public catalog for booking
router.get('/', getDoctors);

router.get('/me/profile', protect, authorize('doctor'), getMyDoctorProfile);
router.post('/', protect, requirePermission(PERMISSIONS.CREATE_DOCTOR), createDoctor);

router.get('/:id', getDoctor);
router.put('/:id', protect, requirePermission(PERMISSIONS.UPDATE_DOCTOR), updateDoctor);
router.delete('/:id', protect, requirePermission(PERMISSIONS.DELETE_DOCTOR), deleteDoctor);
router.get('/:id/appointments', protect, getDoctorAppointments);

module.exports = router;
