const express = require('express');
const { protect } = require('../middleware/auth');
const router = express.Router();
router.use(protect);
router.post('/chat', async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    if (!messages.length || messages.length > 12 || messages.some(m => !['user','assistant'].includes(m.role) || typeof m.content !== 'string' || m.content.length > 3000)) {
      return res.status(400).json({ message: 'Please send a valid message (up to 3,000 characters).' });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ message: 'AI chat is not configured yet. Add OPENAI_API_KEY to server/.env and restart the backend to enable AI responses.' });
    }
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', temperature: 0.4, max_tokens: 500,
        messages: [{ role: 'system', content: 'You are CareTrack Assistant. Provide concise, general health education and help with the CareTrack application. Never diagnose, prescribe, or claim certainty. Encourage users to consult a qualified clinician for personal medical decisions. For emergency symptoms, advise immediate local emergency care. Do not request passwords or unnecessary sensitive personal data.' }, ...messages] })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ message: data.error?.message || 'The AI provider could not complete the request.' });
    return res.json({ reply: data.choices?.[0]?.message?.content || 'I could not generate a response. Please try again.' });
  } catch (error) { console.error('AI chat error:', error.message); return res.status(500).json({ message: 'AI assistant is temporarily unavailable.' }); }
});
module.exports = router;
