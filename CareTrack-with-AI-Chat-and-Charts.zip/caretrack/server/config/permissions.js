/**
 * Central Role-Based Access Control (RBAC) matrix for CareTrack.
 * Roles: admin | doctor | patient
 */
const ROLES = {
  ADMIN: 'admin',
  DOCTOR: 'doctor',
  PATIENT: 'patient',
};

/** Permission keys used across API and (optionally) UI */
const PERMISSIONS = {
  // Dashboard
  VIEW_ADMIN_DASHBOARD: 'view_admin_dashboard',
  VIEW_DOCTOR_DASHBOARD: 'view_doctor_dashboard',
  VIEW_PATIENT_DASHBOARD: 'view_patient_dashboard',

  // Patients
  LIST_PATIENTS: 'list_patients',
  VIEW_PATIENT: 'view_patient',
  CREATE_PATIENT: 'create_patient',
  UPDATE_PATIENT: 'update_patient',
  DELETE_PATIENT: 'delete_patient',

  // Doctors
  LIST_DOCTORS: 'list_doctors',
  VIEW_DOCTOR: 'view_doctor',
  CREATE_DOCTOR: 'create_doctor',
  UPDATE_DOCTOR: 'update_doctor',
  DELETE_DOCTOR: 'delete_doctor',

  // Appointments
  LIST_APPOINTMENTS: 'list_appointments',
  CREATE_APPOINTMENT: 'create_appointment',
  UPDATE_APPOINTMENT: 'update_appointment',
  DELETE_APPOINTMENT: 'delete_appointment',
  APPROVE_APPOINTMENT: 'approve_appointment',

  // Medical records
  LIST_MEDICAL_RECORDS: 'list_medical_records',
  CREATE_MEDICAL_RECORD: 'create_medical_record',
  UPDATE_MEDICAL_RECORD: 'update_medical_record',
  DELETE_MEDICAL_RECORD: 'delete_medical_record',

  // Registration / system
  REGISTRATION_STATION: 'registration_station',
  MANAGE_USERS: 'manage_users',
};

/**
 * Role → allowed permissions
 * Controllers still enforce ownership (e.g. patient only own records).
 */
const ROLE_PERMISSIONS = {
  [ROLES.ADMIN]: [
    PERMISSIONS.VIEW_ADMIN_DASHBOARD,
    PERMISSIONS.LIST_PATIENTS,
    PERMISSIONS.VIEW_PATIENT,
    PERMISSIONS.CREATE_PATIENT,
    PERMISSIONS.UPDATE_PATIENT,
    PERMISSIONS.DELETE_PATIENT,
    PERMISSIONS.LIST_DOCTORS,
    PERMISSIONS.VIEW_DOCTOR,
    PERMISSIONS.CREATE_DOCTOR,
    PERMISSIONS.UPDATE_DOCTOR,
    PERMISSIONS.DELETE_DOCTOR,
    PERMISSIONS.LIST_APPOINTMENTS,
    PERMISSIONS.CREATE_APPOINTMENT,
    PERMISSIONS.UPDATE_APPOINTMENT,
    PERMISSIONS.DELETE_APPOINTMENT,
    PERMISSIONS.APPROVE_APPOINTMENT,
    PERMISSIONS.LIST_MEDICAL_RECORDS,
    PERMISSIONS.CREATE_MEDICAL_RECORD,
    PERMISSIONS.UPDATE_MEDICAL_RECORD,
    PERMISSIONS.DELETE_MEDICAL_RECORD,
    PERMISSIONS.REGISTRATION_STATION,
    PERMISSIONS.MANAGE_USERS,
  ],
  [ROLES.DOCTOR]: [
    PERMISSIONS.VIEW_DOCTOR_DASHBOARD,
    PERMISSIONS.LIST_PATIENTS,
    PERMISSIONS.VIEW_PATIENT,
    PERMISSIONS.LIST_DOCTORS,
    PERMISSIONS.VIEW_DOCTOR,
    PERMISSIONS.UPDATE_DOCTOR, // own profile only (enforced in controller)
    PERMISSIONS.LIST_APPOINTMENTS,
    PERMISSIONS.UPDATE_APPOINTMENT,
    PERMISSIONS.APPROVE_APPOINTMENT,
    PERMISSIONS.LIST_MEDICAL_RECORDS,
    PERMISSIONS.CREATE_MEDICAL_RECORD,
    PERMISSIONS.UPDATE_MEDICAL_RECORD,
  ],
  [ROLES.PATIENT]: [
    PERMISSIONS.VIEW_PATIENT_DASHBOARD,
    PERMISSIONS.VIEW_PATIENT, // own only
    PERMISSIONS.UPDATE_PATIENT, // own only
    PERMISSIONS.LIST_DOCTORS,
    PERMISSIONS.VIEW_DOCTOR,
    PERMISSIONS.LIST_APPOINTMENTS, // own only
    PERMISSIONS.CREATE_APPOINTMENT,
    PERMISSIONS.UPDATE_APPOINTMENT, // cancel own only
    PERMISSIONS.LIST_MEDICAL_RECORDS, // own only
  ],
};

function roleHasPermission(role, permission) {
  const list = ROLE_PERMISSIONS[role] || [];
  return list.includes(permission);
}

function getPermissionsForRole(role) {
  return ROLE_PERMISSIONS[role] || [];
}

module.exports = {
  ROLES,
  PERMISSIONS,
  ROLE_PERMISSIONS,
  roleHasPermission,
  getPermissionsForRole,
};
