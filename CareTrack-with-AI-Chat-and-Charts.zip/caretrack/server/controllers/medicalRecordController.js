const MedicalRecord = require('../models/MedicalRecord');
const Patient = require('../models/Patient');
const Doctor = require('../models/Doctor');

// @desc    Get medical records
// @route   GET /api/medical-records
// @access  Private
const getMedicalRecords = async (req, res) => {
  try {
    const { patientId } = req.query;
    const filter = {};

    if (req.user.role === 'patient') {
      const patient = await Patient.findOne({ user: req.user._id });
      if (!patient) return res.json([]);
      filter.patient = patient._id;
    } else if (req.user.role === 'doctor') {
      const doctor = await Doctor.findOne({ user: req.user._id });
      if (!doctor) return res.json([]);
      filter.doctor = doctor._id;
      if (patientId) filter.patient = patientId;
    } else if (patientId) {
      filter.patient = patientId;
    }

    const records = await MedicalRecord.find(filter)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email' },
      })
      .sort({ recordDate: -1 });

    res.json(records);
  } catch (error) {
    console.error('Get medical records error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get single medical record
// @route   GET /api/medical-records/:id
// @access  Private
const getMedicalRecord = async (req, res) => {
  try {
    const record = await MedicalRecord.findById(req.params.id)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email' },
      });

    if (!record) {
      return res.status(404).json({ message: 'Medical record not found' });
    }

    // Authorization check
    if (req.user.role === 'patient') {
      const patient = await Patient.findOne({ user: req.user._id });
      if (!patient || record.patient._id.toString() !== patient._id.toString()) {
        return res.status(403).json({ message: 'Not authorized' });
      }
    }

    res.json(record);
  } catch (error) {
    console.error('Get medical record error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Create medical record
// @route   POST /api/medical-records
// @access  Private (Doctor, Admin)
const createMedicalRecord = async (req, res) => {
  try {
    const {
      patientId,
      appointmentId,
      diagnosis,
      symptoms,
      treatment,
      notes,
      prescriptions,
      vitalSigns,
      followUpDate,
    } = req.body;

    if (!patientId || !diagnosis) {
      return res.status(400).json({ message: 'Patient and diagnosis are required' });
    }

    let doctorId;
    if (req.user.role === 'doctor') {
      const doctor = await Doctor.findOne({ user: req.user._id });
      if (!doctor) {
        return res.status(404).json({ message: 'Doctor profile not found' });
      }
      doctorId = doctor._id;
    } else {
      doctorId = req.body.doctorId;
      if (!doctorId) {
        return res.status(400).json({ message: 'Doctor ID is required' });
      }
    }

    const patient = await Patient.findById(patientId);
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    const record = await MedicalRecord.create({
      patient: patientId,
      doctor: doctorId,
      appointment: appointmentId || undefined,
      diagnosis,
      symptoms: symptoms || '',
      treatment: treatment || '',
      notes: notes || '',
      prescriptions: prescriptions || [],
      vitalSigns: vitalSigns || {},
      followUpDate: followUpDate || undefined,
      recordDate: new Date(),
    });

    const populated = await MedicalRecord.findById(record._id)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email' },
      });

    res.status(201).json(populated);
  } catch (error) {
    console.error('Create medical record error:', error);
    res.status(500).json({ message: error.message || 'Server error' });
  }
};

// @desc    Update medical record
// @route   PUT /api/medical-records/:id
// @access  Private (Doctor, Admin)
const updateMedicalRecord = async (req, res) => {
  try {
    const record = await MedicalRecord.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: 'Medical record not found' });
    }

    if (req.user.role === 'doctor') {
      const doctor = await Doctor.findOne({ user: req.user._id });
      if (!doctor || record.doctor.toString() !== doctor._id.toString()) {
        return res.status(403).json({ message: 'Not authorized to update this record' });
      }
    }

    const fields = [
      'diagnosis',
      'symptoms',
      'treatment',
      'notes',
      'prescriptions',
      'vitalSigns',
      'followUpDate',
    ];
    fields.forEach((field) => {
      if (req.body[field] !== undefined) {
        record[field] = req.body[field];
      }
    });

    await record.save();

    const updated = await MedicalRecord.findById(record._id)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email' },
      });

    res.json(updated);
  } catch (error) {
    console.error('Update medical record error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Delete medical record
// @route   DELETE /api/medical-records/:id
// @access  Private (Admin)
const deleteMedicalRecord = async (req, res) => {
  try {
    const record = await MedicalRecord.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: 'Medical record not found' });
    }

    await MedicalRecord.findByIdAndDelete(req.params.id);
    res.json({ message: 'Medical record deleted successfully' });
  } catch (error) {
    console.error('Delete medical record error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  getMedicalRecords,
  getMedicalRecord,
  createMedicalRecord,
  updateMedicalRecord,
  deleteMedicalRecord,
};
