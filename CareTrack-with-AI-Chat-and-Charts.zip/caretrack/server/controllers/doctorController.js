const Doctor = require('../models/Doctor');
const User = require('../models/User');
const Appointment = require('../models/Appointment');

// @desc    Get all doctors
// @route   GET /api/doctors
// @access  Public / Private
const getDoctors = async (req, res) => {
  try {
    const { search, specialization, available } = req.query;
    let doctors = await Doctor.find()
      .populate('user', 'name email phone gender isActive')
      .sort({ createdAt: -1 });

    // Filter only active doctors for public
    doctors = doctors.filter((d) => d.user && d.user.isActive);

    if (search) {
      const s = search.toLowerCase();
      doctors = doctors.filter(
        (d) =>
          d.user?.name?.toLowerCase().includes(s) ||
          d.specialization?.toLowerCase().includes(s) ||
          d.department?.toLowerCase().includes(s)
      );
    }

    if (specialization) {
      doctors = doctors.filter(
        (d) => d.specialization?.toLowerCase() === specialization.toLowerCase()
      );
    }

    if (available === 'true') {
      doctors = doctors.filter((d) => d.isAvailable);
    }

    res.json(doctors);
  } catch (error) {
    console.error('Get doctors error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get single doctor
// @route   GET /api/doctors/:id
// @access  Public / Private
const getDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id).populate(
      'user',
      'name email phone gender isActive'
    );

    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found' });
    }

    res.json(doctor);
  } catch (error) {
    console.error('Get doctor error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Create doctor (Admin)
// @route   POST /api/doctors
// @access  Private (Admin)
const createDoctor = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
      phone,
      gender,
      specialization,
      qualification,
      experience,
      consultationFee,
      availability,
      department,
      licenseNumber,
      bio,
    } = req.body;

    if (!name || !email || !password || !specialization || consultationFee === undefined) {
      return res.status(400).json({
        message: 'Name, email, password, specialization and consultation fee are required',
      });
    }

    const userExists = await User.findOne({ email: email.toLowerCase() });
    if (userExists) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password,
      phone,
      gender,
      role: 'doctor',
    });

    const doctor = await Doctor.create({
      user: user._id,
      specialization,
      qualification,
      experience: experience || 0,
      consultationFee,
      availability: availability || [],
      department,
      licenseNumber,
      bio,
      isAvailable: true,
    });

    const populated = await Doctor.findById(doctor._id).populate(
      'user',
      'name email phone gender isActive'
    );

    res.status(201).json(populated);
  } catch (error) {
    console.error('Create doctor error:', error);
    res.status(500).json({ message: error.message || 'Server error' });
  }
};

// @desc    Update doctor
// @route   PUT /api/doctors/:id
// @access  Private (Admin or self)
const updateDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id).populate('user');

    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found' });
    }

    if (req.user.role === 'doctor' && doctor.user._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // Update user
    if (req.body.name) doctor.user.name = req.body.name;
    if (req.body.phone) doctor.user.phone = req.body.phone;
    if (req.body.gender) doctor.user.gender = req.body.gender;
    if (req.body.isActive !== undefined && req.user.role === 'admin') {
      doctor.user.isActive = req.body.isActive;
    }
    await doctor.user.save();

    // Update doctor fields
    if (req.body.specialization) doctor.specialization = req.body.specialization;
    if (req.body.qualification !== undefined) doctor.qualification = req.body.qualification;
    if (req.body.experience !== undefined) doctor.experience = req.body.experience;
    if (req.body.consultationFee !== undefined) doctor.consultationFee = req.body.consultationFee;
    if (req.body.availability) doctor.availability = req.body.availability;
    if (req.body.department !== undefined) doctor.department = req.body.department;
    if (req.body.licenseNumber !== undefined) doctor.licenseNumber = req.body.licenseNumber;
    if (req.body.bio !== undefined) doctor.bio = req.body.bio;
    if (req.body.isAvailable !== undefined) doctor.isAvailable = req.body.isAvailable;

    await doctor.save();

    const updated = await Doctor.findById(doctor._id).populate(
      'user',
      'name email phone gender isActive'
    );

    res.json(updated);
  } catch (error) {
    console.error('Update doctor error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Delete doctor
// @route   DELETE /api/doctors/:id
// @access  Private (Admin)
const deleteDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found' });
    }

    await User.findByIdAndUpdate(doctor.user, { isActive: false });
    await Doctor.findByIdAndDelete(req.params.id);

    res.json({ message: 'Doctor removed successfully' });
  } catch (error) {
    console.error('Delete doctor error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get doctor's appointments
// @route   GET /api/doctors/:id/appointments
// @access  Private
const getDoctorAppointments = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);
    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found' });
    }

    if (req.user.role === 'doctor' && doctor.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const appointments = await Appointment.find({ doctor: req.params.id })
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .sort({ date: -1 });

    res.json(appointments);
  } catch (error) {
    console.error('Get doctor appointments error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get current doctor's own profile
// @route   GET /api/doctors/me/profile
// @access  Private (Doctor)
const getMyDoctorProfile = async (req, res) => {
  try {
    const doctor = await Doctor.findOne({ user: req.user._id }).populate(
      'user',
      'name email phone gender isActive'
    );

    if (!doctor) {
      return res.status(404).json({ message: 'Doctor profile not found' });
    }

    res.json(doctor);
  } catch (error) {
    console.error('Get my doctor profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  getDoctors,
  getDoctor,
  createDoctor,
  updateDoctor,
  deleteDoctor,
  getDoctorAppointments,
  getMyDoctorProfile,
};
