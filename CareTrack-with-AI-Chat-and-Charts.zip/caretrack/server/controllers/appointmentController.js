const Appointment = require('../models/Appointment');
const Patient = require('../models/Patient');
const Doctor = require('../models/Doctor');

// @desc    Get all appointments
// @route   GET /api/appointments
// @access  Private
const getAppointments = async (req, res) => {
  try {
    const { status, date, doctorId, patientId } = req.query;
    const filter = {};

    if (status) filter.status = status;
    if (doctorId) filter.doctor = doctorId;
    if (patientId) filter.patient = patientId;
    if (date) {
      const start = new Date(date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(date);
      end.setHours(23, 59, 59, 999);
      filter.date = { $gte: start, $lte: end };
    }

    // Role-based filtering
    if (req.user.role === 'patient') {
      const patient = await Patient.findOne({ user: req.user._id });
      if (!patient) return res.json([]);
      filter.patient = patient._id;
    } else if (req.user.role === 'doctor') {
      const doctor = await Doctor.findOne({ user: req.user._id });
      if (!doctor) return res.json([]);
      filter.doctor = doctor._id;
    }

    const appointments = await Appointment.find(filter)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email phone' },
      })
      .sort({ date: -1, time: 1 });

    res.json(appointments);
  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get single appointment
// @route   GET /api/appointments/:id
// @access  Private
const getAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email phone' },
      });

    if (!appointment) {
      return res.status(404).json({ message: 'Appointment not found' });
    }

    res.json(appointment);
  } catch (error) {
    console.error('Get appointment error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Create appointment
// @route   POST /api/appointments
// @access  Private
const createAppointment = async (req, res) => {
  try {
    const { doctorId, patientId, date, time, reason, notes } = req.body;

    if (!doctorId || !date || !time) {
      return res.status(400).json({ message: 'Doctor, date and time are required' });
    }

    let patient;
    if (req.user.role === 'patient') {
      patient = await Patient.findOne({ user: req.user._id });
      if (!patient) {
        return res.status(404).json({ message: 'Patient profile not found' });
      }
    } else {
      if (!patientId) {
        return res.status(400).json({ message: 'Patient ID is required' });
      }
      patient = await Patient.findById(patientId);
      if (!patient) {
        return res.status(404).json({ message: 'Patient not found' });
      }
    }

    const doctor = await Doctor.findById(doctorId);
    if (!doctor) {
      return res.status(404).json({ message: 'Doctor not found' });
    }

    // Check for double booking
    const appointmentDate = new Date(date);
    appointmentDate.setHours(0, 0, 0, 0);

    const existing = await Appointment.findOne({
      doctor: doctorId,
      date: {
        $gte: appointmentDate,
        $lt: new Date(appointmentDate.getTime() + 24 * 60 * 60 * 1000),
      },
      time,
      status: { $nin: ['cancelled', 'rejected'] },
    });

    if (existing) {
      return res.status(400).json({
        message: 'This time slot is already booked for the selected doctor',
      });
    }

    const appointment = await Appointment.create({
      patient: patient._id,
      doctor: doctorId,
      date: appointmentDate,
      time,
      reason: reason || '',
      notes: notes || '',
      status: 'pending',
      createdBy: req.user._id,
    });

    const populated = await Appointment.findById(appointment._id)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email phone' },
      });

    res.status(201).json(populated);
  } catch (error) {
    console.error('Create appointment error:', error);
    if (error.code === 11000) {
      return res.status(400).json({ message: 'This time slot is already booked' });
    }
    res.status(500).json({ message: error.message || 'Server error' });
  }
};

// @desc    Update appointment
// @route   PUT /api/appointments/:id
// @access  Private
const updateAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({ message: 'Appointment not found' });
    }

    // Status updates
    if (req.body.status) {
      const allowedStatuses = ['pending', 'approved', 'completed', 'cancelled', 'rejected'];
      if (!allowedStatuses.includes(req.body.status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }

      // Patients can only cancel
      if (req.user.role === 'patient' && req.body.status !== 'cancelled') {
        return res.status(403).json({ message: 'Patients can only cancel appointments' });
      }

      appointment.status = req.body.status;
    }

    if (req.body.notes !== undefined) appointment.notes = req.body.notes;
    if (req.body.reason !== undefined) appointment.reason = req.body.reason;
    if (req.body.date) appointment.date = new Date(req.body.date);
    if (req.body.time) appointment.time = req.body.time;

    await appointment.save();

    const updated = await Appointment.findById(appointment._id)
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name email phone gender dateOfBirth' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email phone' },
      });

    res.json(updated);
  } catch (error) {
    console.error('Update appointment error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Delete appointment
// @route   DELETE /api/appointments/:id
// @access  Private (Admin)
const deleteAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);

    if (!appointment) {
      return res.status(404).json({ message: 'Appointment not found' });
    }

    await Appointment.findByIdAndDelete(req.params.id);
    res.json({ message: 'Appointment deleted successfully' });
  } catch (error) {
    console.error('Delete appointment error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get dashboard stats
// @route   GET /api/appointments/stats/dashboard
// @access  Private (Admin)
const getDashboardStats = async (req, res) => {
  try {
    const Patient = require('../models/Patient');
    const Doctor = require('../models/Doctor');
    const User = require('../models/User');

    const totalPatients = await Patient.countDocuments();
    const totalDoctors = await Doctor.countDocuments();
    const totalAppointments = await Appointment.countDocuments();
    const pendingAppointments = await Appointment.countDocuments({ status: 'pending' });
    const completedAppointments = await Appointment.countDocuments({ status: 'completed' });
    const approvedAppointments = await Appointment.countDocuments({ status: 'approved' });
    const cancelledAppointments = await Appointment.countDocuments({ status: 'cancelled' });

    const recentPatients = await Patient.find()
      .populate('user', 'name email phone createdAt')
      .sort({ createdAt: -1 })
      .limit(5);

    const recentAppointments = await Appointment.find()
      .populate({
        path: 'patient',
        populate: { path: 'user', select: 'name' },
      })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name' },
      })
      .sort({ createdAt: -1 })
      .limit(5);

    // Appointments by status for chart
    const appointmentsByStatus = {
      pending: pendingAppointments,
      approved: approvedAppointments,
      completed: completedAppointments,
      cancelled: cancelledAppointments,
    };

    res.json({
      totalPatients,
      totalDoctors,
      totalAppointments,
      pendingAppointments,
      completedAppointments,
      approvedAppointments,
      cancelledAppointments,
      recentPatients,
      recentAppointments,
      appointmentsByStatus,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  getAppointments,
  getAppointment,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  getDashboardStats,
};
