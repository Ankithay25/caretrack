const Patient = require('../models/Patient');
const User = require('../models/User');
const Appointment = require('../models/Appointment');

// @desc    Get all patients
// @route   GET /api/patients
// @access  Private (Admin, Doctor)
const getPatients = async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const query = {};

    let patients = await Patient.find(query)
      .populate('user', 'name email phone gender dateOfBirth address isActive createdAt')
      .sort({ createdAt: -1 });

    if (search) {
      const searchLower = search.toLowerCase();
      patients = patients.filter(
        (p) =>
          p.user?.name?.toLowerCase().includes(searchLower) ||
          p.user?.email?.toLowerCase().includes(searchLower) ||
          p.user?.phone?.includes(search)
      );
    }

    const total = patients.length;
    const start = (page - 1) * limit;
    const paginated = patients.slice(start, start + Number(limit));

    res.json({
      patients: paginated,
      total,
      page: Number(page),
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get single patient
// @route   GET /api/patients/:id
// @access  Private
const getPatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id).populate(
      'user',
      'name email phone gender dateOfBirth address isActive createdAt'
    );

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    // Patients can only view their own profile
    if (req.user.role === 'patient') {
      if (patient.user._id.toString() !== req.user._id.toString()) {
        return res.status(403).json({ message: 'Not authorized' });
      }
    }

    res.json(patient);
  } catch (error) {
    console.error('Get patient error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Create patient (Admin)
// @route   POST /api/patients
// @access  Private (Admin)
const createPatient = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
      phone,
      gender,
      dateOfBirth,
      address,
      bloodGroup,
      emergencyContact,
      allergies,
      chronicConditions,
      insuranceProvider,
      insuranceNumber,
      notes,
    } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email and password are required' });
    }

    const userExists = await User.findOne({ email: email.toLowerCase() });
    if (userExists) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password,
      phone,
      gender,
      dateOfBirth,
      address,
      role: 'patient',
    });

    const patient = await Patient.create({
      user: user._id,
      bloodGroup,
      emergencyContact,
      allergies: allergies || [],
      chronicConditions: chronicConditions || [],
      insuranceProvider,
      insuranceNumber,
      notes,
    });

    const populated = await Patient.findById(patient._id).populate(
      'user',
      'name email phone gender dateOfBirth address isActive createdAt'
    );

    res.status(201).json(populated);
  } catch (error) {
    console.error('Create patient error:', error);
    res.status(500).json({ message: error.message || 'Server error' });
  }
};

// @desc    Update patient
// @route   PUT /api/patients/:id
// @access  Private (Admin or self)
const updatePatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id).populate('user');

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    if (req.user.role === 'patient' && patient.user._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // Update user fields
    if (req.body.name) patient.user.name = req.body.name;
    if (req.body.phone) patient.user.phone = req.body.phone;
    if (req.body.gender) patient.user.gender = req.body.gender;
    if (req.body.dateOfBirth) patient.user.dateOfBirth = req.body.dateOfBirth;
    if (req.body.address) patient.user.address = req.body.address;
    if (req.body.isActive !== undefined && req.user.role === 'admin') {
      patient.user.isActive = req.body.isActive;
    }
    await patient.user.save();

    // Update patient fields
    if (req.body.bloodGroup !== undefined) patient.bloodGroup = req.body.bloodGroup;
    if (req.body.emergencyContact) patient.emergencyContact = req.body.emergencyContact;
    if (req.body.allergies) patient.allergies = req.body.allergies;
    if (req.body.chronicConditions) patient.chronicConditions = req.body.chronicConditions;
    if (req.body.insuranceProvider !== undefined) patient.insuranceProvider = req.body.insuranceProvider;
    if (req.body.insuranceNumber !== undefined) patient.insuranceNumber = req.body.insuranceNumber;
    if (req.body.notes !== undefined) patient.notes = req.body.notes;

    await patient.save();

    const updated = await Patient.findById(patient._id).populate(
      'user',
      'name email phone gender dateOfBirth address isActive createdAt'
    );

    res.json(updated);
  } catch (error) {
    console.error('Update patient error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Delete patient
// @route   DELETE /api/patients/:id
// @access  Private (Admin)
const deletePatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    // Soft delete: deactivate user
    await User.findByIdAndUpdate(patient.user, { isActive: false });
    await Patient.findByIdAndDelete(req.params.id);

    res.json({ message: 'Patient removed successfully' });
  } catch (error) {
    console.error('Delete patient error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get patient appointments
// @route   GET /api/patients/:id/appointments
// @access  Private
const getPatientAppointments = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    if (req.user.role === 'patient' && patient.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const appointments = await Appointment.find({ patient: req.params.id })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email phone' },
      })
      .sort({ date: -1 });

    res.json(appointments);
  } catch (error) {
    console.error('Get patient appointments error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get current patient's own profile
// @route   GET /api/patients/me/profile
// @access  Private (Patient)
const getMyPatientProfile = async (req, res) => {
  try {
    const patient = await Patient.findOne({ user: req.user._id }).populate(
      'user',
      'name email phone gender dateOfBirth address isActive createdAt'
    );

    if (!patient) {
      return res.status(404).json({ message: 'Patient profile not found' });
    }

    res.json(patient);
  } catch (error) {
    console.error('Get my profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  getPatients,
  getPatient,
  createPatient,
  updatePatient,
  deletePatient,
  getPatientAppointments,
  getMyPatientProfile,
};
