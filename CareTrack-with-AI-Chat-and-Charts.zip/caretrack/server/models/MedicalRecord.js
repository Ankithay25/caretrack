const mongoose = require('mongoose');

const medicalRecordSchema = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
    },
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Doctor',
      required: true,
    },
    appointment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Appointment',
    },
    diagnosis: {
      type: String,
      required: [true, 'Please provide diagnosis'],
    },
    symptoms: {
      type: String,
      default: '',
    },
    treatment: {
      type: String,
      default: '',
    },
    notes: {
      type: String,
      default: '',
    },
    prescriptions: [
      {
        medicine: {
          type: String,
          required: true,
        },
        dosage: {
          type: String,
          required: true,
        },
        frequency: {
          type: String,
          required: true,
        },
        duration: {
          type: String,
          required: true,
        },
        instructions: {
          type: String,
          default: '',
        },
      },
    ],
    vitalSigns: {
      bloodPressure: String,
      heartRate: String,
      temperature: String,
      weight: String,
      height: String,
    },
    followUpDate: {
      type: Date,
    },
    recordDate: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('MedicalRecord', medicalRecordSchema);
