/**
 * Force-create or reset the admin account password.
 * Run from server folder: node scripts/resetAdmin.js
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');

const ADMIN_EMAIL = 'admin@caretrack.com';
const ADMIN_PASSWORD = 'admin123';

async function resetAdmin() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    let admin = await User.findOne({ email: ADMIN_EMAIL }).select('+password');

    if (admin) {
      admin.password = ADMIN_PASSWORD;
      admin.role = 'admin';
      admin.isActive = true;
      admin.name = admin.name || 'System Admin';
      await admin.save(); // triggers bcrypt hash via pre-save
      console.log('Admin password RESET successfully');
    } else {
      admin = await User.create({
        name: 'System Admin',
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
        phone: '9000000000',
        role: 'admin',
        gender: 'other',
        isActive: true,
      });
      console.log('Admin account CREATED successfully');
    }

    console.log('');
    console.log('Use these credentials:');
    console.log('  Email:    admin@caretrack.com');
    console.log('  Password: admin123');
    console.log('');
    process.exit(0);
  } catch (err) {
    console.error('Failed:', err.message);
    console.error('');
    console.error('Check:');
    console.error('  1. MongoDB is running');
    console.error('  2. MONGODB_URI in server/.env is correct');
    console.error('     Example: mongodb://localhost:27017/caretrack');
    process.exit(1);
  }
}

resetAdmin();
