/**
 * CareTrack seed script — realistic clinic data for demos & interviews
 * Run: npm run seed
 *
 * Clears nothing by default; skips records that already exist by email.
 * For a full reset, drop the caretrack database first.
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Doctor = require('../models/Doctor');
const Patient = require('../models/Patient');
const Appointment = require('../models/Appointment');
const MedicalRecord = require('../models/MedicalRecord');

const WEEKDAY_AVAIL = [
  { day: 'Monday', startTime: '09:00', endTime: '17:00' },
  { day: 'Tuesday', startTime: '09:00', endTime: '17:00' },
  { day: 'Wednesday', startTime: '09:00', endTime: '17:00' },
  { day: 'Thursday', startTime: '09:00', endTime: '17:00' },
  { day: 'Friday', startTime: '09:00', endTime: '13:00' },
];

const DOCTORS = [
  {
    name: 'Dr. Sarah Johnson',
    email: 'doctor@caretrack.com',
    password: 'doctor123',
    phone: '9001001001',
    gender: 'female',
    specialization: 'General Medicine',
    qualification: 'MBBS, MD',
    experience: 12,
    consultationFee: 50,
    department: 'Internal Medicine',
    licenseNumber: 'DOC-2024-001',
    bio: 'Primary care physician focusing on preventive health and chronic disease management.',
  },
  {
    name: 'Dr. James Smith',
    email: 'dr.smith@caretrack.com',
    password: 'doctor123',
    phone: '9001001002',
    gender: 'male',
    specialization: 'Cardiology',
    qualification: 'MBBS, MD, DM Cardiology',
    experience: 15,
    consultationFee: 80,
    department: 'Cardiology',
    licenseNumber: 'DOC-2024-002',
    bio: 'Senior cardiologist specializing in hypertension, heart failure, and ECG interpretation.',
  },
  {
    name: 'Dr. Priya Patel',
    email: 'dr.patel@caretrack.com',
    password: 'doctor123',
    phone: '9001001003',
    gender: 'female',
    specialization: 'Pediatrics',
    qualification: 'MBBS, MD Pediatrics',
    experience: 9,
    consultationFee: 60,
    department: 'Pediatrics',
    licenseNumber: 'DOC-2024-003',
    bio: 'Child specialist covering newborn care, vaccinations, and common pediatric illnesses.',
  },
  {
    name: 'Dr. Michael Chen',
    email: 'dr.chen@caretrack.com',
    password: 'doctor123',
    phone: '9001001004',
    gender: 'male',
    specialization: 'Orthopedics',
    qualification: 'MBBS, MS Orthopedics',
    experience: 11,
    consultationFee: 75,
    department: 'Orthopedics',
    licenseNumber: 'DOC-2024-004',
    bio: 'Orthopedic surgeon for sports injuries, joint pain, and fracture follow-up.',
  },
  {
    name: 'Dr. Aisha Rahman',
    email: 'dr.rahman@caretrack.com',
    password: 'doctor123',
    phone: '9001001005',
    gender: 'female',
    specialization: 'Dermatology',
    qualification: 'MBBS, MD Dermatology',
    experience: 8,
    consultationFee: 70,
    department: 'Dermatology',
    licenseNumber: 'DOC-2024-005',
    bio: 'Dermatologist treating acne, eczema, hair loss, and skin infections.',
  },
  {
    name: 'Dr. Robert Williams',
    email: 'dr.williams@caretrack.com',
    password: 'doctor123',
    phone: '9001001006',
    gender: 'male',
    specialization: 'Neurology',
    qualification: 'MBBS, MD, DM Neurology',
    experience: 14,
    consultationFee: 90,
    department: 'Neurology',
    licenseNumber: 'DOC-2024-006',
    bio: 'Neurologist for migraine, seizures, neuropathy, and stroke rehabilitation support.',
  },
  {
    name: 'Dr. Emily Brown',
    email: 'dr.brown@caretrack.com',
    password: 'doctor123',
    phone: '9001001007',
    gender: 'female',
    specialization: 'Gynecology',
    qualification: 'MBBS, MS Obstetrics & Gynecology',
    experience: 10,
    consultationFee: 65,
    department: 'Obstetrics & Gynecology',
    licenseNumber: 'DOC-2024-007',
    bio: 'Women’s health, antenatal care, and routine gynecological consultations.',
  },
  {
    name: 'Dr. Arjun Mehta',
    email: 'dr.mehta@caretrack.com',
    password: 'doctor123',
    phone: '9001001008',
    gender: 'male',
    specialization: 'ENT',
    qualification: 'MBBS, MS ENT',
    experience: 7,
    consultationFee: 55,
    department: 'ENT',
    licenseNumber: 'DOC-2024-008',
    bio: 'Ear, nose, and throat specialist for sinusitis, hearing issues, and tonsillitis.',
  },
];

const PATIENTS = [
  { name: 'John Doe', email: 'patient@caretrack.com', password: 'patient123', phone: '8002002001', gender: 'male', dateOfBirth: '1990-05-15', address: '12 Oak Street, Springfield', bloodGroup: 'O+', allergies: ['Penicillin'], chronicConditions: [] },
  { name: 'Maria Garcia', email: 'maria.garcia@email.com', password: 'patient123', phone: '8002002002', gender: 'female', dateOfBirth: '1985-08-22', address: '45 Pine Avenue, Riverside', bloodGroup: 'A+', allergies: [], chronicConditions: ['Hypertension'] },
  { name: 'David Kim', email: 'david.kim@email.com', password: 'patient123', phone: '8002002003', gender: 'male', dateOfBirth: '1992-11-03', address: '78 Maple Road, Lakeside', bloodGroup: 'B+', allergies: ['Dust'], chronicConditions: ['Asthma'] },
  { name: 'Sophie Martin', email: 'sophie.martin@email.com', password: 'patient123', phone: '8002002004', gender: 'female', dateOfBirth: '1998-01-17', address: '3 Cedar Lane, Hilltown', bloodGroup: 'AB+', allergies: [], chronicConditions: [] },
  { name: 'Rajesh Kumar', email: 'rajesh.kumar@email.com', password: 'patient123', phone: '8002002005', gender: 'male', dateOfBirth: '1978-06-30', address: '90 Lake View, Metro City', bloodGroup: 'O-', allergies: ['Seafood'], chronicConditions: ['Type 2 Diabetes'] },
  { name: 'Emma Wilson', email: 'emma.wilson@email.com', password: 'patient123', phone: '8002002006', gender: 'female', dateOfBirth: '1995-03-12', address: '21 River Street, Greenfield', bloodGroup: 'A-', allergies: [], chronicConditions: [] },
  { name: 'Carlos Rivera', email: 'carlos.rivera@email.com', password: 'patient123', phone: '8002002007', gender: 'male', dateOfBirth: '1988-09-25', address: '56 Hill Crest, Westside', bloodGroup: 'B-', allergies: ['Latex'], chronicConditions: [] },
  { name: 'Aisha Khan', email: 'aisha.khan@email.com', password: 'patient123', phone: '8002002008', gender: 'female', dateOfBirth: '1993-12-08', address: '14 Garden Colony, East Park', bloodGroup: 'O+', allergies: [], chronicConditions: ['Migraine'] },
  { name: 'Thomas Lee', email: 'thomas.lee@email.com', password: 'patient123', phone: '8002002009', gender: 'male', dateOfBirth: '1975-04-19', address: '88 Industrial Road, Northend', bloodGroup: 'A+', allergies: ['Aspirin'], chronicConditions: ['Hypertension', 'High Cholesterol'] },
  { name: 'Fatima Ali', email: 'fatima.ali@email.com', password: 'patient123', phone: '8002002010', gender: 'female', dateOfBirth: '2000-07-14', address: '5 Sunrise Apartments, Downtown', bloodGroup: 'AB-', allergies: [], chronicConditions: [] },
  { name: 'William Turner', email: 'william.turner@email.com', password: 'patient123', phone: '8002002011', gender: 'male', dateOfBirth: '1982-02-28', address: '33 Bridge Street, Harbor', bloodGroup: 'O+', allergies: [], chronicConditions: ['Back pain'] },
  { name: 'Nina Volkov', email: 'nina.volkov@email.com', password: 'patient123', phone: '8002002012', gender: 'female', dateOfBirth: '1991-10-05', address: '19 Rose Garden, Southside', bloodGroup: 'B+', allergies: ['Pollen'], chronicConditions: [] },
];

const TIMES = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00'];
const REASONS = [
  'Routine checkup',
  'Fever and body ache',
  'Follow-up visit',
  'Chest discomfort',
  'Skin rash',
  'Joint pain',
  'Headache for 3 days',
  'Vaccination counseling',
  'Blood pressure review',
  'Allergy symptoms',
  'Pregnancy consultation',
  'Ear infection',
];
const DIAGNOSES = [
  'Viral upper respiratory infection',
  'Essential hypertension — controlled',
  'Allergic rhinitis',
  'Mechanical low back pain',
  'Acne vulgaris',
  'Migraine without aura',
  'Type 2 diabetes mellitus — follow-up',
  'Acute otitis media',
  'Gastritis',
  'Seasonal allergic dermatitis',
];

function daysFromToday(offset) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + offset);
  return d;
}

const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB\n');

    // —— Admin ——
    let admin = await User.findOne({ email: 'admin@caretrack.com' });
    if (!admin) {
      admin = await User.create({
        name: 'System Admin',
        email: 'admin@caretrack.com',
        password: 'admin123',
        phone: '9000000000',
        role: 'admin',
        gender: 'other',
      });
      console.log('✓ Admin created');
    } else {
      console.log('· Admin already exists');
    }

    // —— Doctors ——
    const doctorDocs = [];
    for (const d of DOCTORS) {
      let user = await User.findOne({ email: d.email });
      if (!user) {
        user = await User.create({
          name: d.name,
          email: d.email,
          password: d.password,
          phone: d.phone,
          role: 'doctor',
          gender: d.gender,
        });
        const doc = await Doctor.create({
          user: user._id,
          specialization: d.specialization,
          qualification: d.qualification,
          experience: d.experience,
          consultationFee: d.consultationFee,
          department: d.department,
          licenseNumber: d.licenseNumber,
          bio: d.bio,
          availability: WEEKDAY_AVAIL,
          isAvailable: true,
        });
        doctorDocs.push(doc);
        console.log(`✓ Doctor: ${d.name} (${d.specialization})`);
      } else {
        const existing = await Doctor.findOne({ user: user._id });
        if (existing) doctorDocs.push(existing);
        console.log(`· Doctor exists: ${d.name}`);
      }
    }

    // —— Patients ——
    const patientDocs = [];
    for (const p of PATIENTS) {
      let user = await User.findOne({ email: p.email });
      if (!user) {
        user = await User.create({
          name: p.name,
          email: p.email,
          password: p.password,
          phone: p.phone,
          role: 'patient',
          gender: p.gender,
          dateOfBirth: new Date(p.dateOfBirth),
          address: p.address,
        });
        const patient = await Patient.create({
          user: user._id,
          bloodGroup: p.bloodGroup,
          allergies: p.allergies || [],
          chronicConditions: p.chronicConditions || [],
          emergencyContact: {
            name: 'Emergency Contact',
            phone: '9999999999',
            relation: 'Family',
          },
        });
        patientDocs.push(patient);
        console.log(`✓ Patient: ${p.name}`);
      } else {
        const existing = await Patient.findOne({ user: user._id });
        if (existing) patientDocs.push(existing);
        console.log(`· Patient exists: ${p.name}`);
      }
    }

    // —— Appointments (only if few exist) ——
    const apptCount = await Appointment.countDocuments();
    if (apptCount < 15 && doctorDocs.length && patientDocs.length) {
      const statuses = ['pending', 'approved', 'completed', 'completed', 'approved', 'cancelled', 'pending'];
      let created = 0;
      for (let i = 0; i < 28; i++) {
        const doctor = doctorDocs[i % doctorDocs.length];
        const patient = patientDocs[i % patientDocs.length];
        const dayOffset = (i % 14) - 5; // mix past & future
        const date = daysFromToday(dayOffset);
        const time = TIMES[i % TIMES.length];
        const status = statuses[i % statuses.length];

        try {
          await Appointment.create({
            patient: patient._id,
            doctor: doctor._id,
            date,
            time,
            status,
            reason: REASONS[i % REASONS.length],
            notes: status === 'completed' ? 'Visit completed as scheduled.' : '',
            createdBy: admin._id,
          });
          created++;
        } catch {
          // skip unique index conflicts
        }
      }
      console.log(`✓ Appointments created: ${created}`);
    } else {
      console.log(`· Appointments already present (${apptCount})`);
    }

    // —— Medical records for completed visits ——
    const recordCount = await MedicalRecord.countDocuments();
    if (recordCount < 8 && doctorDocs.length && patientDocs.length) {
      const completed = await Appointment.find({ status: 'completed' }).limit(12);
      let recs = 0;
      for (let i = 0; i < completed.length; i++) {
        const a = completed[i];
        const exists = await MedicalRecord.findOne({ appointment: a._id });
        if (exists) continue;

        await MedicalRecord.create({
          patient: a.patient,
          doctor: a.doctor,
          appointment: a._id,
          diagnosis: DIAGNOSES[i % DIAGNOSES.length],
          symptoms: a.reason || 'As reported during consultation',
          treatment: 'Symptomatic care, lifestyle advice, and medication as prescribed.',
          notes: 'Patient advised to follow up if symptoms persist beyond 5 days.',
          prescriptions: [
            {
              medicine: i % 2 === 0 ? 'Paracetamol 500mg' : 'Amoxicillin 250mg',
              dosage: i % 2 === 0 ? '1 tablet' : '1 capsule',
              frequency: i % 2 === 0 ? 'Every 6–8 hours as needed' : 'Three times daily after food',
              duration: i % 2 === 0 ? '3 days' : '5 days',
              instructions: 'Do not exceed recommended dose. Complete the course if antibiotic.',
            },
          ],
          vitalSigns: {
            bloodPressure: `${110 + (i % 20)}/${70 + (i % 10)}`,
            heartRate: `${72 + (i % 15)}`,
            temperature: `${36.5 + (i % 10) * 0.1}`,
            weight: `${60 + (i % 25)}`,
          },
          recordDate: a.date || new Date(),
        });
        recs++;
      }
      console.log(`✓ Medical records created: ${recs}`);
    } else {
      console.log(`· Medical records already present (${recordCount})`);
    }

    const totals = {
      doctors: await Doctor.countDocuments(),
      patients: await Patient.countDocuments(),
      appointments: await Appointment.countDocuments(),
      records: await MedicalRecord.countDocuments(),
    };

    console.log('\n========== CareTrack seed complete ==========');
    console.log(`Doctors: ${totals.doctors} | Patients: ${totals.patients}`);
    console.log(`Appointments: ${totals.appointments} | Medical records: ${totals.records}`);
    console.log('\nLogin credentials:');
    console.log('  Admin:   admin@caretrack.com / admin123');
    console.log('  Doctor:  doctor@caretrack.com / doctor123');
    console.log('  Patient: patient@caretrack.com / patient123');
    console.log('  (All other seeded doctors use password: doctor123)');
    console.log('  (All other seeded patients use password: patient123)');
    console.log('==============================================\n');

    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
};

seedData();
